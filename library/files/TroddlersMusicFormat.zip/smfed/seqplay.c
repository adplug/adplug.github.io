#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <string.h>
#include <xtypes.h>

#include "midi.h"
#include "globdat.h"
#include "scrwin.h"
#include "node2win.h"
#include "windata.h"
#include "inslist.h"
#include "insedit.h"
#include "saveload.h"
#include "options.h"
#include "events.h"
#include "seqmain.h"
#include "midiemu.h"

main(int argc,char**argv)
{
	struct	songnode *activesong = NULL;

	if (argc!=2)
	{
		printf("\nUsage: seqplay <filename>\n");
		exit(1);
	}

   // set timer interrupt to function timerint and initialize timer frequency
   // to 70Hz
	settimerint();
	emuinit();
	activesong = &song;/* default song */
	loadmusicdata(argv[1], activesong);
	playsong(activesong);
	restoretimerint();
	return 0;
}
