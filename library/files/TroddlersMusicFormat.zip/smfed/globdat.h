#ifndef GLOBDAT_H
#define GLOBDAT_H

extern struct track trk;
extern struct sequence seq;
extern struct songnode song;

extern int		songdirty,
				patchdirty,
                tonedirty;

extern int		emumidi;
extern int		gs;			/* use bank select values ? */

extern unsigned char inpbuf[];
extern int	 bufr,bufw;

extern int		echo; /* MIDI through on/off */
extern unsigned char	recchnl; /* MIDI channel -1 */
extern unsigned char	lastcmd; /* high 4 bits of last MIDI command
							/* used by all MIDI read functions in MIDI.C
/*extern int		recbank;   // record instrument gs-bank select value
extern int		recprogram;// record instrument program change value
extern int		recinstr;  // record instrument (scope is temp)
extern int		program; // initial program #

extern int		defpatch[];
extern int		defbank[];  bank number of midi channels
extern int		defprog[];  program number of midi channels
extern int		pbsens[];

extern int		quantize; /* recording resolution in ticks
extern int		veloffs;  /* velocity offset *
extern int		velsens;  /* velocity sensitivity in % *
extern int		countin; /* #of measures to count in before record *
extern int		repeat; /* repeat sequence / track on/off *
extern long	ignoremsg;    /* bitmask of combined messages to ignore *

xtern int		seqnum; /* active sequence *
extern int		seqnumserial;/* serial number of last created sequence */
extern int		nodeserialnumber;
extern int		numseq; /* total number of sequences */

extern int		seqlen; /* number of measures (in active sequence) */
extern int		bpmeas; /* number of beats per measure */
extern int		tickbeat;/* number of ticks per beat */

extern int		mclock;/* ticks per second (remains constant during tune) */
extern int		mclockpct;/* percentage of master clock (use for record) */

extern int		metronome; /* metronome on/off */
extern int		playbackmetronome; /* play metronome sound on playback too on/off*/
extern int		midimetronome;/* midi or internal (0 = internal) */
extern int		metrolen; /* metronome sound length in ticks */
extern int		timecount; /* timer on/off */

extern volatile long	tick; /* tick count (resets every beat) */
extern volatile int		metcnt; /* metronome sound length count */
extern volatile int		beat; /* beat count - resets every measure */
extern volatile int		measure; /* measure count - resets at tune start */
extern volatile int		restarted; /* !0 when track restarted */

extern char **seqwindowstr;
extern char **trackwindowstr;

extern int dataport;
extern int cmdport;

#endif
