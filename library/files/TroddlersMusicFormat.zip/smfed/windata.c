#include <stdlib.h>
#include <conio.h>

#include "scrwin.h"

struct scrwindow mainwindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	1,1,80,24,
	NULL,
	"MPU Sequencer",
	WHITE,BLUE
};

struct scrwindow songwindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	2,2,63,18,
	NULL,
	"Song Edit",
	BLACK,CYAN
};

struct scrwindow seqeditwindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	3,3,50,15,
	NULL,
	"Sequence Edit",
	BLACK,GREEN
};

struct scrwindow tracklistwindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	5,5,40,18,
	NULL,
	"Select Track",
	BLUE,CYAN
};

struct scrwindow seqlistwindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	5,5,50,14,
	NULL,
	"Select Sequence",
	LIGHTGRAY,RED
};

struct scrwindow trackeditwindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	3,7,60,17,
	NULL,
	"Track Edit",
	RED,LIGHTGRAY
};

char *recordoptstr[] =
{
	"Tempo factor",
	"Channel Change",
	"Instrument",
	"Quantize",
	"Velocity Sens",
	"Name Track",
	"Transpose Track",
	"Align Events",
	"Clone Track",
	"Track Length",
	"Beats/Measure",
	"Ticks/Beat",
	"Scale Velocity",
	"Count-in",
	"Monophonize",
    "GS MIDI",
	NULL
};

int recordopthi[] =
{
	0,0,0,0,0,0,1,0,2,6,0,3,0,2,0,0
};

char recordopthot[] = "tciqvnraolbksumg";

struct scrwindow recoptionswindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	40,4,65,21,
	NULL,
	"Record Options",
	WHITE,BLACK,
	0,0,
	recordopthi,
	recordopthot
};

char rpnoptstrings[] =
{
	""
};

int rpnopthi[] = {0};
char rpnopthot[] = "";

struct scrwindow rpnoptionswindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	5,5,40,15,
	NULL,
	"PRN Options",
	WHITE,RED,
    0,0,
	rpnopthi,
    rpnopthot
};


struct scrwindow eventlistwindow =
{
	{NULL,NULL,NT_SCRWIN,0},
	35,7,70,22,
	NULL,
	"Event list",
	YELLOW,BLUE
};
