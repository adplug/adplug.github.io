#include <stdio.h>

FILE *fileopen(char *, char *);
void fileclose(FILE *);
