/*	ADLIB hardware interface for MIDIEMU.C.

	(C)1992 Johannes Bjerregaard.

	Uses VELODATA.C & DRUMSET.C

*/

#include <xtypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <conio.h>
#include "adlib.h"
#include "drumset.h"
#include "file.h"

void updateregspace(void);

struct tinstrument *_insdata;	/* instrument data table */

extern UBYTE _regspace[];
extern UBYTE _regwork[];

UWORD fqdata[128];		/* frequency data for each note */
						/* initialized in hw_loadinstruments() */

UBYTE hwvkey[9];		/* key number for hw voice */

extern UBYTE velotab[128];		/* velocity reference table */


/*	Operator offset table */

UBYTE vcop[9] =    {0,1,2,8,9,10,16,17,18};

UBYTE hwreg20[22];				/* contents of hardware register 20h */
								/* used with noteoff decay+sustain */

/*	remembers information on contents of the hw-register
	that must be changed at noteoff */

UBYTE noteoninfo[9];

UBYTE _pbsens;					/* pitch bend sens in half notes (1 - 24) */
								/* set by midiemu */

WORD  _pbvalue[9]; 				/* pitch bend values (-2000h - 2000h) */
								/* set by midiemu */

UBYTE _modvalue[9];				/* modulator values (0-7fh) */
								/* set by midiemu */

UWORD hwvtime[9];				/* time since last noteon */
UBYTE hwvmodlfocnt[9];			/* mod lfo counter */

UWORD hwvfq[9];					/* base frequency as calculated outside   */
								/* of real-time sound processing routine  */
								/* includes initial setting of pitch bend */

UBYTE hwvins[9];				/* instrument used with voice */

void adl_noteon(UBYTE ins, UBYTE vno,
 UBYTE ky, UBYTE vel)
{
	UBYTE	op1,op2,reg,dat;
	UWORD	temp;
	struct	tinstrument *ip;

	hwvins[vno] = ins;

	vel = velotab[vel];			/* pipe velocity through translation table */
								/* to correct to linear value */

	hwvkey[vno] = ky;
	hwvmodlfocnt[vno]=0;		/* mod lfo count */

	ip = 	&_insdata[ins];

	op1 = 	vcop[vno]+3;
	op2 = 	vcop[vno];

	/*	clear voice */

   asm cli

   if (hwvtime[vno])
   {
	  hwvtime[vno] = 0;			/* reset note-on time */

	  reg	= 0xb0+vno;
	  dat = 0;
	  OUTADL

	  reg = 0x80+op1;
	  dat = 0xff;
	  OUTADL

	  reg = 0x60+op1;
	  dat = 0xff;
	  OUTADL

	  reg = 0x80+op2;
	  dat = 0xff;
	  OUTADL

	  reg = 0x60+op2;
	  dat = 0xff;
	  OUTADL
	  updateregspace();
   }
	/*	set up carrier */

	reg = 	op1 + 0x20;
	dat =  (ip->frequency_multiplier	[CARRIER]) 		     |
			((ip->envelope_scaling		[CARRIER]!=0)	<< 4)|
			((ip->sustaining_sound		[CARRIER]!=0)	<< 5)|
			((ip->frequency_vibrato		[CARRIER]!=0)	<< 6)|
			((ip->amplitude_vibrato		[CARRIER]!=0)	<< 7);

	hwreg20[op1] = dat;

	OUTADL

	reg =	op1 + 0x40;

	temp=	ip->output_level[CARRIER] -
				((ip->velo_sens[CARRIER] * vel ) / 64);
    if (temp > 64) temp=0;

	dat	=	temp | (ip->key_scale_level[CARRIER] << 6);
	OUTADL

	reg =	op1 + 0x60;
	dat =	(ip->attack_rate[CARRIER] << 4) + ip->decay_rate[CARRIER];
	OUTADL

	reg =	op1 + 0x80;
	dat =	(ip->sustain_level[CARRIER] << 4) + ip->release_rate[CARRIER];
	OUTADL

	reg	=	op1 + 0xe0;
	dat	=	ip->wave_form_for_carrier;
	OUTADL

	/*	set up modulator */

	reg = 	op2 + 0x20;

	dat = 	 (ip->frequency_multiplier	[MODULATOR]) 		 |
			((ip->envelope_scaling		[MODULATOR]!=0)	<< 4)|
			((ip->sustaining_sound		[MODULATOR]!=0)	<< 5)|
			((ip->frequency_vibrato		[MODULATOR]!=0)	<< 6)|
			((ip->amplitude_vibrato		[MODULATOR]!=0)	<< 7);

	hwreg20[op2] = dat;

	OUTADL

	reg =	op2 + 0x40;

	if (!ip->combine_method)	/* Parallel uses velocity */
		temp=	0x3f - (((0x3f - (ip->output_level[MODULATOR])) * vel)/64);
	else						/* FM uses not velocity */
	{
		temp=	ip->output_level[MODULATOR] -
					((ip->velo_sens[MODULATOR] * vel ) / 64);

    	if (temp > 63) temp = 0;				/* that is, if (temp < 0) */
    }
	dat	=	temp | (ip->key_scale_level[MODULATOR] << 6);
	OUTADL

	reg =	op2 + 0x60;
	dat =	(ip->attack_rate[MODULATOR] << 4) + ip->decay_rate[MODULATOR];
	OUTADL

	reg =	op2 + 0x80;
	dat =	(ip->sustain_level[MODULATOR] << 4) + ip->release_rate[MODULATOR];
	OUTADL

	reg	=	op2 + 0xe0;
	dat	=	ip->wave_form_for_modulator;
	OUTADL

	/*	set up common parameters */

	reg =	0xc0 + vno;
	dat =	(!ip->combine_method) | (ip->feed_back[MODULATOR]<<1);
	OUTADL

	noteoninfo[vno] = 0x20;

	hw_pbchange(vno);

   asm sti
}

void hw_pbchange(UBYTE hwv)
{
	UWORD	d;
	UBYTE 	numhalf;
	BYTE	whnote;
	UWORD 	rest,fqrest;
	WORD	pbvalue;

	pbvalue = _pbvalue[hwv];

	if (pbvalue > 0)
	{
		numhalf = (UWORD)(((long)_pbsens * pbvalue) / 0x2000);
		rest    = (UWORD)(((long)_pbsens * pbvalue) % 0x2000);

		whnote = hwvkey[hwv]+numhalf; /* ny "hel" halvtone */

		fqrest = fqdata[whnote+1]-fqdata[whnote];/* rest i f-num */
		if (fqrest > 680) fqrest -= 680;

		d = fqdata[whnote] + (UWORD)((((long)fqrest * rest) / 0x2000));

	} else
	if (pbvalue < 0)
	{
		pbvalue = -pbvalue;

		numhalf = (UWORD)(((long)_pbsens * pbvalue) / 0x2000);
		rest    = (UWORD)(((long)_pbsens * pbvalue) % 0x2000);

		whnote = hwvkey[hwv]-numhalf; /* ny "hel" halvtone */

		fqrest = fqdata[whnote]-fqdata[whnote-1];/* rest i f-num */
		if (fqrest > 680) fqrest -= 680;

		d = fqdata[whnote-1] + (fqrest-(UWORD)((((long)fqrest * rest) / 0x2000)));
	} else d = fqdata[hwvkey[hwv]];

	hwvfq[hwv] = d;		/* set base frequency of voice */
}

void hw_drumon(UBYTE voice, UBYTE key, UBYTE velocity)
{
	UBYTE	ins,note;

	ins = drumins[key];		/* instrument number to use for drum tone */
	note= drumnote[key];

	adl_noteon(ins,voice,note,velocity);
}


void hw_noteon(UBYTE voice, UBYTE note, UBYTE velocity, UBYTE instr)
{
	adl_noteon(instr,voice,note,velocity);
}


void hw_noteoff(UBYTE voice)
{
	UBYTE	reg,dat,op1,op2;
	struct tinstrument *ip;


	ip = &_insdata[hwvins[voice]];

	op1 = 	vcop[voice]+3;
	op2 = 	vcop[voice];

	/*	set keyoff decay + sustain */

	reg =	op1 + 0x60;
	dat =	(ip->attack_rate[CARRIER] << 4) + ip->keyoff_decay_rate[CARRIER];
	OUTADL

	reg =	op2 + 0x60;
	dat =	(ip->attack_rate[MODULATOR] << 4) + ip->keyoff_decay_rate[MODULATOR];
	OUTADL

	reg =	op1 + 0x80;
	dat =	(ip->keyoff_sustain_level[CARRIER] << 4)+ip->release_rate[CARRIER];
	OUTADL

	reg =	op2 + 0x80;
	dat =	(ip->keyoff_sustain_level[MODULATOR] << 4)+ip->release_rate[MODULATOR];
	OUTADL

	/*	clear sustaining sound */

	reg =	op1 + 0x20;
    dat =   hwreg20[op1] & (0xff-0x20);
	OUTADL

	reg =	op2 + 0x20;
    dat =   hwreg20[op2] & (0xff-0x20);
	OUTADL
}


static void hw_initfqdata(void)
{
	int	b,n,q;
	UWORD v;
	double	fq=16.352;/* C, octave 0 */
	double	pow2i12;

	pow2i12 = pow(2.0,1.0/12.0);

	for (b=0;b<8;b++)
		for (n=0;n<12;n++)
		{
			v = (UWORD) (fq * pow(2.0,20.0-b) / 49716.0);
			q = v + (b << 10);
			fqdata[12+(b*12)+n] = q;
			fq = fq * pow2i12;
		}
/*
   // create a frequency table on file

   {
      FILE *fl;

      fl = fopen("fqdata.bin","wb");
      if (fl==0)
      {
         printf("Can't create fqdata.bin\n");
         exit(1);
      }
      fwrite(fqdata,sizeof(fqdata[0]),128,fl);
      fclose(fl);
      exit(0);
   }
*/
}


/*	ensure melodic mode & wave select enable */

static void hw_initadlib(void)
{
   asm mov ax,1
   outadl();

   asm mov ax,2001h
   outadl();

   asm mov ax,0bdh
   outadl();

   asm mov cx,9
l9v:
   asm mov ax,00b0h
   asm add al,cl
   outadl();
   asm loop l9v

   asm mov cx,16h
l18v:
   asm mov ax,3f40h
   asm add al,cl
   outadl();
   asm loop l18v
}


static void hw_initdrumtables(void)
{
}

BOOL hw_loadinstruments(char far *filename)
{
	FILE	*f;
	size_t	n;

	if ((f = fileopen(filename,"rb"))==NULL)
		return FALSE;
	n=fread(_insdata,sizeof(struct tinstrument),NUMINSTRUMENTS,f);
	fileclose(f);
	if (n != NUMINSTRUMENTS) return FALSE;
	return TRUE;
}

BOOL hw_saveinstruments(char *filename)
{
	FILE	*f;
	size_t	n;

	if ((f = fileopen(filename,"wb"))==NULL)
		return FALSE;
	n=fwrite(_insdata,sizeof(struct tinstrument),NUMINSTRUMENTS,f);
	fileclose(f);
	if (n != NUMINSTRUMENTS) return FALSE;
	return TRUE;
}

/*	initialize module + hardware for MIDI processing */

BOOL hw_emuinit(void)
{
	_insdata = calloc(NUMINSTRUMENTS,sizeof(struct tinstrument));
	if (_insdata == NULL) return FALSE;

	hw_initfqdata();
	hw_initdrumtables();
	hw_initadlib();

	return TRUE;
}
