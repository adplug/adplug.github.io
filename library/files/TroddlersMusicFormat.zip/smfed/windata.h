#include "scrwin.h"

extern struct scrwindow mainwindow,
	seqeditwindow,tracklistwindow,trackeditwindow,seqlistwindow,
	songwindow,recoptionswindow,eventlistwindow;

extern char *optionstr[],*fileoptstr[],*recordoptstr[],*trackoptstr[],
			*seqoptstr[];
