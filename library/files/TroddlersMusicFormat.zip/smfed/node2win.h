#include "midi.h"

void buildseqlist(void);
void buildtracklist(void);
char **buildseqtracks(struct sequence *);
char **buildsongseq(struct songnode *);
void freestrings(char **);
int nodecount(struct ln_node *);
