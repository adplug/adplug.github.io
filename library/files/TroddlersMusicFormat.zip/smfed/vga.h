void vgasetcolor(unsigned char,unsigned char);
