#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <mem.h>
#include <string.h>
#include <alloc.h>
#include <dir.h>
#include <ctype.h>

#include "adlib.h"
#include "patchdat.h"
#include "inslist.h"

#include "smfptune.h"

struct tinstrument loadedinsdata[256];       // loaded tone parameters
struct compactinstrument outinsdata[256];    // reorganized tone parameters

unsigned char loadedpatchtable[256][2];

struct smfptune tune;
// this table holds the patch numbers which are used by the MIDI file being
// squeezed.
unsigned char usedpatches[256];
int numusedpatches=0;
// this table is updated when the instruments from a patch are moved from
// one location to another. the original position of the instrument (tone)
// is in movedins[x][0] and the new position is in movedins[x][1]. Before
// moving an instrument to movedins[nummovedins++], check if the instrument
// has already been moved. if so, replace the instrument numbers in the
// patch table with the number found in movedins[x][1].
unsigned char movedins[256];
int nummovedins=0; // nummovedins also equals the number of tones actually
                   // used by the MIDI file.
int movedposition(int tone)
// returns the position of a tone in the instrument data
// if the tone has not yet been moved into place, returns -1.
{
   int i;
   if (tone==255) return tone;
   for (i=0;i<nummovedins;i++)
   {
      if (tone==movedins[i]) return i;
   }
   return -1;
}
int patchused(int patch)
// returns 1 if patch is in the usedpatches table
{
   int i;
   for (i=0;i<numusedpatches;i++)
      if (usedpatches[i]==patch) return 1;
   return 0;
}
void squeezepatches(void)
{
   int i,j,tone,mtone,patch;
   int newposition=0;

   // move the patch numbers from 128 and upwards into empty slots below 128
   // while updating the drum patch table.

   for (i=0;i<numusedpatches;i++)
   {
      int p;
      if ((p=usedpatches[i])>=128)
      {
         // move the patch down to below 128

         while (patchused(newposition)) newposition++;
         usedpatches[i]=newposition;

         loadedpatchtable[newposition][0]=loadedpatchtable[p][0];
         loadedpatchtable[newposition][1]=loadedpatchtable[p][1];

         // replace all occurences from drumins table with new patch number

         for (j=0;j<128;j++)
         {
            if (tune.drumins[j]==p)
            {
               tune.drumins[j]=newposition;
            }
         }
      }
   }
   // squeeze the tone definition data

   for (i=0;i<numusedpatches;i++)
   {
      patch=usedpatches[i];
      tone = loadedpatchtable[patch][0];
      mtone = movedposition(tone);
      if (mtone==-1) // tone not used before
      {
         movedins[nummovedins] = tone;
         mtone = nummovedins++;
      }
      tune.patchtable[patch][0]=mtone;

      tone = loadedpatchtable[patch][1];
      mtone = movedposition(tone);
      if (mtone==-1) // tone not used before
      {
         movedins[nummovedins] = tone;
         mtone = nummovedins++;
      }
      tune.patchtable[patch][1]=mtone;
   }

   // rebuild the tone definition data

   for (i=0;i<nummovedins;i++)
   {
      int from;
      from = movedins[i];

      outinsdata[i].reg20[0]=
         loadedinsdata[from].frequency_multiplier[0]|
         (loadedinsdata[from].envelope_scaling[0]<<4)|
         (loadedinsdata[from].sustaining_sound[0]<<5)|
         (loadedinsdata[from].frequency_vibrato[0]<<6)|
         (loadedinsdata[from].amplitude_vibrato[0]<<7);

      outinsdata[i].reg40[0]=
         loadedinsdata[from].key_scale_level[0]<<6;

      outinsdata[i].reg60[0]=
         loadedinsdata[from].decay_rate[0]|
         (loadedinsdata[from].attack_rate[0]<<4);

      outinsdata[i].reg80[0]=
         loadedinsdata[from].release_rate[0]|
         (loadedinsdata[from].sustain_level[0]<<4);

      outinsdata[i].keyoff_reg60[0]=
         loadedinsdata[from].keyoff_decay_rate[0]|
         (loadedinsdata[from].attack_rate[0]<<4);

      outinsdata[i].keyoff_reg80[0]=
         loadedinsdata[from].release_rate[0]|
         (loadedinsdata[from].keyoff_sustain_level[0]<<4);

      outinsdata[i].velo_sens[0]=
         loadedinsdata[from].velo_sens[0];


      outinsdata[i].reg20[1]=
         loadedinsdata[from].frequency_multiplier[1]|
         (loadedinsdata[from].envelope_scaling[1]<<4)|
         (loadedinsdata[from].sustaining_sound[1]<<5)|
         (loadedinsdata[from].frequency_vibrato[1]<<6)|
         (loadedinsdata[from].amplitude_vibrato[1]<<7);

      outinsdata[i].reg40[1]=
         loadedinsdata[from].key_scale_level[1]<<6;

      outinsdata[i].reg60[1]=
         loadedinsdata[from].decay_rate[1]|
         (loadedinsdata[from].attack_rate[1]<<4);

      outinsdata[i].reg80[1]=
         loadedinsdata[from].release_rate[1]|
         (loadedinsdata[from].sustain_level[1]<<4);

      outinsdata[i].keyoff_reg60[1]=
         loadedinsdata[from].keyoff_decay_rate[1]|
         (loadedinsdata[from].attack_rate[1]<<4);

      outinsdata[i].keyoff_reg80[1]=
         loadedinsdata[from].release_rate[1]|
         (loadedinsdata[from].keyoff_sustain_level[1]<<4);

      outinsdata[i].velo_sens[1]=
         loadedinsdata[from].velo_sens[1];

      outinsdata[i].regc0=
         (loadedinsdata[from].combine_method^1)|
         (loadedinsdata[from].feed_back[0]<<1);


      outinsdata[i].mod_lfo_depth = loadedinsdata[from].mod_lfo_depth;
      outinsdata[i].mod_lfo_rate = loadedinsdata[from].mod_lfo_rate;
      outinsdata[i].detune = loadedinsdata[from].detune;
      outinsdata[i].tvp_depth = loadedinsdata[from].tvp_depth;
      outinsdata[i].tvp_rate = loadedinsdata[from].tvp_rate;
      outinsdata[i].coarse_detune = loadedinsdata[from].coarse_detune;

      outinsdata[i].wave_form_for_carrier =
         loadedinsdata[from].wave_form_for_carrier;
      outinsdata[i].wave_form_for_modulator =
         loadedinsdata[from].wave_form_for_modulator;

      outinsdata[i].output_level[0]=
         loadedinsdata[from].output_level[0];
      outinsdata[i].output_level[1]=
         loadedinsdata[from].output_level[1];



   }
}



int loadsmfptune(const char *musicname) // no extension
{
	FILE *f;
   char fn[MAXPATH];

   strcpy(fn,musicname);
   strcat(fn,".pat");

   if ((f=fopen(fn,"rb"))==NULL)
   {
      printf("Cannot open file %s.\n",fn);
      exit(1);
   }

	fread(&loadedpatchtable,sizeof(struct patchcomp),256,f); /* tone reference table */
	fseek(f,sizeof(struct patch)*512,SEEK_CUR);
	fseek(f,16*256,SEEK_CUR);
	fread(&tune.drumins,128,1,f);
	fread(&tune.drumnote,128,1,f);
   fread(&tune.channelmaxvoice,16,1,f);
   fread(&tune.drumpriority,128,1,f);
   fread(&tune.channelpriority,16,1,f);
   fclose(f);

   strcpy(fn,musicname);
   strcat(fn,".ins");

   if ((f=fopen(fn,"rb"))==NULL)
   {
      printf("Cannot open file %s.\n",fn);
      exit(1);
   }
   fread(&loadedinsdata,sizeof(struct tinstrument),256,f);
   fclose(f);
   return 0;
}

void usage(void)
{
   printf("Usage: smfpak\n");
   exit(1);
}

main(int argc)
{
   char c;
   char fn[MAXPATH];
   char npatch[256];
   int n,pn,r=1;
   int i;
   char *p;
   FILE *f;

   if (argc!=1) usage();

   memset(&tune,0,sizeof(tune));

   // load music info from ins and pat files

   printf("Enter name part of file to squeeze    : ");
   scanf("%s",fn);
   loadsmfptune(fn);

   // get patch numbers actually used by MIDI file

   printf("Enter patch numbers used by MIDI file : ");
   fflush(stdin);
   gets(npatch);

   // parse entered patch numbers

   p=npatch;

   for(;;)
   {
      r=sscanf(p,"%d%n",&pn,&n);
      if (r<=0) break;
      usedpatches[numusedpatches++]=pn;
      p+=n;
   }

   // get miscellaneous information used to store in header

   for (;;)
   {
      char s[80];
      printf("Copyright string                      : ");
      fflush(stdin);
      gets(s);
      if (strlen(s)>31)
      {
         printf("Maximum number of characters is 31.\n");
         continue;
      }
      strcpy(tune.copyright,s);
      break;
   }

   for (;;)
   {
      char s[80];
      printf("Loop tune at end ?                    : ");
      fflush(stdin);
      gets(s);
      strlwr(s);
      if (strcmp(s,"y")&&strcmp(s,"n"))
      {
         printf("Please type either \"y\" or \"n\".\n");
         continue;
      }
      if (*s=='y') tune.loop = 1;
      else tune.loop = 0;
      break;
   }

   for (;;)
   {
      printf("Output format (0=AdLib)               : ");
      fflush(stdin);
      scanf("%d",&i);
      if (i<0 || i>1)
      {
         printf("Valid range is 0-0.\n");
         continue;
      }
      tune.outputformat=i;
      break;
   }

   for (;;)
   {
      printf("Number of voices in sound hardware    : ");
      fflush(stdin);
      scanf("%d",&i);
      if (i<1 || i>255)
      {
         printf("Valid range is 1-255.\n");
         continue;
      }
      tune.numvoices=i;
      break;
   }

   for (;;)
   {
      printf("Default semitone range of pitch bend  : ");
      fflush(stdin);
      scanf("%d",&i);
      if (i<0||i>24)
      {
         printf("Valid range is 0-24\n");
         continue;
      }
      tune.pitchbenddefault=i;
      break;
   }

   strncpy(tune.id,"SMFP",4);    // standard midi file patch
   tune.version = 0x0100;        // msb=major, lsb=minor

   squeezepatches();             // thisiswhereeverythinghappens.

   printf("Output filename                       : ");
   scanf("%s",fn);
   f=fopen(fn,"wb");
   if (f==0)
   {
      printf("Can't open %s for writing.\n",fn);
      exit(1);
   }
   fwrite(&tune,sizeof(tune)-sizeof(struct compactinstrument),1,f);
   fwrite(outinsdata,sizeof(struct compactinstrument),nummovedins,f);
   fclose(f);

   printf("Thanks for using smfpak.\n(C)1993 Johannes Bjerregaard. All rights reserved.\n");
   return 0;
}
