/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#pragma hdrstop
#include "FM801.h"
#include "giveio.h"
#pragma package(smart_init)

FM801::FM801(USHORT address)
{
        FM801Base= address;
        opl3= new OPL3(FM801Base + FM801_OPL3);
        if(opl3==NULL)
                throw "Couldn't create an opl3 instance";
}

FM801::~FM801(void)
{
        delete opl3;
}

void FM801::writeFmVol(BYTE leftvol, BYTE rightvol)
{
        USHORT muted= inpw(FM801Base + FM801_FMOUTVOL) & 0x8000;
        rightvol &= 31;
        leftvol  &= 31;
        outpw(FM801Base + FM801_FMOUTVOL, muted | (rightvol<<8) | leftvol);
}

void FM801::readFmVol(BOOLEAN &muted, BYTE &leftvol, BYTE &rightvol)
{
        USHORT value= inpw(FM801Base + FM801_FMOUTVOL);
        muted= (value & 0x8000) ? TRUE : FALSE;
        leftvol= value & 31;
        rightvol= (value >> 8) & 31;
}

void FM801::muteFmVol(void)
{
        USHORT value= inpw(FM801Base + FM801_FMOUTVOL);
        outpw(FM801Base + FM801_FMOUTVOL, value | 0x8000);
}

void FM801::unmuteFmVol(void)
{
        USHORT value= inpw(FM801Base + FM801_FMOUTVOL);
        outpw(FM801Base + FM801_FMOUTVOL, value & 0x7fff);
}