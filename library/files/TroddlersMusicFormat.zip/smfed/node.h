#ifndef NODE_H
#define NODE_H

#define NT_START		0		/* 1st node */
#define NT_TRACK     	1		/* node types */
#define NT_SEQUENCE  	2
#define NT_UNDEFINED 	3

#define NT_KBDENTRY		4		/* keyboard entry */
#define NT_SCRWIN		5		/* (scroll) window */

struct ln_node
{
	struct ln_node	*succ;
	struct ln_node	*pred;
	int		nodetype;
	unsigned number;/* node ID */
};

#endif