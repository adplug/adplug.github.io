/*	MIDI emulation functions for AdLib.

	This module is hardware independent.

	(C)1992 Johannes Bjerregaard.

*/

#include <dos.h>
#include <stdio.h>
#include <stdlib.h>

#include "adlib.h"
#include "midimsg.h"
#include "midiemu.h"
#include "patchdat.h"
#include "drumset.h"
#include "text.h"

#define	NUMVOICES 9
#define  DRUM_MIN_PRIORITY 10 // drum key assignments with a priority higher
                              // than or equal to this number will NOT be
                              // considered when a channel needs to take a
                              // voice from another channel (in the function
                              // stealvoice()


/*	------------------- MODULE STATIC VARIABLES ------------------- */

/*	MIDI processing variables */

static unsigned char cmd;						/* value of command byte */
static unsigned char cc;						/* control change /  msg */
static unsigned char expected;					/* next value expected */
static unsigned char databyte;					/* value of message data */
static unsigned char chnl;						/* active midi channel */

/*  Channel variables */

unsigned char gsbank[16],program[16];	/* active sound for channel */
static unsigned char modvalue[16];				/* value of modulation control */
static unsigned char voiceref[16][128][2];		/* [channel][note number][tone] ref */
										/* to hardware voice numbers */
static int  chnlpbvalue[16];			/* value of pitch bend for chnls */
static unsigned char numnoteson[16];			/* #notes on for chnl. 0-15 */
static unsigned char hold1[16];					/* value of hold1 */
static unsigned char chnlref[NUMVOICES];		/* hardware voice number reference */
										      /* to midi channel */
static unsigned char freevoice[NUMVOICES];		/* free voices (0xff = free), otherwise key number */
static unsigned char voicepriority[NUMVOICES]; /* priority of note in voice (drums only) */
static unsigned char chnlvolumevalue[16]; /* output volume of individual voices */
static unsigned char chnlexpressionvalue[16]; /* output volume of individual voices */

unsigned char channelpriority[16];          // priority of voices on this channel
unsigned char channelmaxvoice[16];          // max. #voices to spend on a each chnl
unsigned char channelnumvoice[16];          // #voices currently allocated to each

static unsigned char rpnlsb; // LSB of RPN, currently only lsb is needed to handle
                     // the only processed data entry of pitch bend sens.
                     // all msb settings are ignored

/*	Temporary variables */

static	unsigned char note;
static	unsigned char velocity;



unsigned char	findfreevoice(void)
//	Returnerer nummeret p� en ledig HW-stemme (0 - NUMVOICES-1)
//	Hvis der ikke er nogen i �jeblikket, returneres NUMVOICES
// (condition 1)
{
	unsigned char	i,vc=NUMVOICES;
	unsigned	hitime=0;

	for (i=0;i<NUMVOICES;i++)
		if (freevoice[i]==255)
      {
         if (hitime <= hwvtime[i])
		   {
			   hitime = hwvtime[i];
			   vc = i;
		   }
      }
   return vc;
}

unsigned char replacevoice(unsigned char ch, unsigned char key)
// if all reserved voices have been used on this channel,
// finds the voice using the specified channel which has been on for
// the longest time. It does not replace notes that have been turned
// on less than 1 voice tick ago. Not so as for drums, since a priority
// table decides whether a note should replace another one.
// (condition 2)
{
	unsigned char	i,vc=NUMVOICES;
	unsigned	hitime=0;

   if (channelnumvoice[ch]<channelmaxvoice[ch]) return NUMVOICES;

   if (ch==9)
   {
	   int lopri;

	   if (ch==9)
         lopri=drumpriority[key];
      for (i=0;i<NUMVOICES;i++)
      if (chnlref[i]==9)
		{
			if (voicepriority[i]<lopri)
			{
			   lopri = voicepriority[i];
			   vc = i;
			}
      }
   }
   else
   {
	   for (i=0;i<NUMVOICES;i++)
		   if (chnlref[i]==ch)
		 {
			if (hitime <= hwvtime[i])
			  {
				  hitime = hwvtime[i];
				  vc = i;
			  }
		 }
   }
   if (vc!=NUMVOICES)
   {
	  int v2;

	  hw_noteoff(vc);
      v2=voiceref[ch][freevoice[vc]][0];
      if (v2==vc)
         v2=voiceref[ch][freevoice[vc]][1];

      if (v2!=255)
      {
         hw_noteoff(v2);
         freevoice[v2]=255;
         chnlref[v2]=16;
         channelnumvoice[ch]--;
      }
      voiceref[ch][freevoice[vc]][1] = 255;
      voiceref[ch][freevoice[vc]][0] = 255;
      freevoice[vc]=255;
      chnlref[vc]=16;
      channelnumvoice[ch]--;
   }
   return vc;
}

unsigned char stealvoice(unsigned char ch)
// takes a voice from another channel which has exceeded its channel limit
// takes the voice from the channel that has exceeded the limit by most voices
// (condition 3)
{
	unsigned char	i,vc=NUMVOICES;
	int	hitime=-1,maxlimit=0;
   int   minpri=DRUM_MIN_PRIORITY;
   unsigned char sc,selc;

	for (i=0;i<NUMVOICES;i++)
   {
      sc=chnlref[i];
      if (channelnumvoice[sc]>channelmaxvoice[sc])
      {
/*         if (sc==9)
         {
            if (voicepriority[i]<minpri)
            {
               minpri=voicepriority[i];
               vc = i;
               selc = sc;
            }
         } else
         if (maxlimit < (channelnumvoice[sc]-channelmaxvoice[sc]))
         {
            maxlimit=channelnumvoice[sc]-channelmaxvoice[sc];
            if (hitime < (int)(hwvtime[i]))
            {
  			      hitime = hwvtime[i];
			      vc = i;
               selc = sc;
            }
         }
*/
            if (voicepriority[i]<minpri)
            {
               minpri=voicepriority[i];
               vc = i;
               selc = sc;
            }
      }
   }
   if (vc!=NUMVOICES)
   {
      int v2;

      channelnumvoice[selc]--;
      hw_noteoff(vc);
      v2=voiceref[selc][freevoice[vc]][0];
      if (v2==vc)
         v2=voiceref[selc][freevoice[vc]][1];
      if (v2!=255)
      {
         hw_noteoff(v2);
         freevoice[v2]=255;
         chnlref[v2]=16;
         channelnumvoice[selc]--;
      }
      voiceref[selc][freevoice[vc]][1] = 255;
      voiceref[selc][freevoice[vc]][0] = 255;
      chnlref[vc]=16;
      freevoice[vc]=255;
   }
   return vc;
}

unsigned char getvoice(unsigned char ch, unsigned char key)
// finds a suitable hardware voice for the specified channel, using the
// three conditions described below and implemented as functions above:
//
// condition 1: if an unused voice exists, take it
//
// condition 2: if this channel's partial reserve limit has been exceeded,
//              replace the voice that has been on for the longest time.
//
// condition 3: if another channel has exceeded its partial reserve limit,
//              take the voice from that channel that has been on for the
//              longest time. the channel from which the voice is taken is
//              the first which satifies the condition. If needed, the chan-
//              nels could be searched through a table if some channels need
//              more "partial-reserve-exceeding" voices than others.
// if all conditions fail (no channel is exceeding its limit), NUMVOICES is
// returned.
{
   unsigned char hwv;

   hwv=findfreevoice();// condition 1: take next free voice
   if (hwv!=NUMVOICES) return hwv;

   hwv=replacevoice(ch,key);// condition 2: replace a voice
   if (hwv!=NUMVOICES) return hwv;

   // only take a voice from another channel if i have at least one voice
   // in spare.

   if (channelnumvoice[ch]<channelmaxvoice[ch])
      hwv=stealvoice(ch); // take a channel from another voice
   else hwv=NUMVOICES;
   return hwv;
}

void processallnotesoffmsg(unsigned char ch)
{
	int	i=0;

	for (i=0;i<NUMVOICES;i++)
	{
      if (chnlref[i]==ch)
		{
			hw_noteoff(i);
         chnlref[i]=16;
			freevoice[i]=255;
      }
   }
   channelnumvoice[ch]=0;

	for (i=0;i<128;i++)
    	voiceref[ch][i][0] = voiceref[ch][i][1] = 255;
}

void processallsoundsoffmsg(unsigned char ch)
{
	int	i;

	for (i=0;i<NUMVOICES;i++)
		if (chnlref[i]==ch)
			if (freevoice[i]==255)
			{
				hw_noteoff(i);
            chnlref[i]=16;
				freevoice[i]=255;
			}
   channelnumvoice[ch]=0;
}

void processnotemsg(unsigned char ch,unsigned char no,unsigned char ve)
{
	unsigned char	hwv;								            /* hardware voice */
	unsigned char	tone;

   int prog;
   int i;
   int nv=0;

   if (ch==9)
      prog=drumins[no];
   else prog=program[ch];

 	if (ve != 0)								         /* noteon event */
	{
      long vl;

      // compensate for channel volume and expression

      vl = (int)ve * chnlvolumevalue[ch];
      vl *= chnlexpressionvalue[ch];
      ve = (int)(vl>>14);

		/* patch voice 1 */

      tone = _patchtable[prog].ins1;

		if (tone != (unsigned char)-1)
		{
		    if ((hwv=voiceref[ch][no][0]) != 255)	/* chnl+note already on */
		    {
			    hw_noteoff(hwv);
		    } else 									      /* find free voice */
		    {
 			    hwv = getvoice(ch,no);
			    if (hwv == NUMVOICES) return;      /* no free voices */
			    freevoice[hwv] = no;					/* mark voice as in-use */
             channelnumvoice[ch]++;
		    }
		    chnlref[hwv] = ch;						   /* set voice reference */
		    voiceref[ch][no][0]=hwv;				   /* remember hardware voice */
		    _pbvalue[hwv] = chnlpbvalue[ch];		/* set pitch bend value */
		    _modvalue[hwv]= modvalue[ch];			/* set modulation value */

          if (ch==9)
          {
             voicepriority[hwv]=drumpriority[no];
             hw_noteon(hwv,drumnote[no],ve,tone);
          }
          else
          {
             voicepriority[hwv]=channelpriority[ch];
             hw_noteon(hwv,no,ve,tone);
          }
	}

		/* patch voice 2 */

      tone = _patchtable[prog].ins2;

		if (tone != (unsigned char)-1)
		{
		    if ((hwv=voiceref[ch][no][1]) != 255)	// chnl+note already on
		    {
			    hw_noteoff(hwv);
		    } else 							       		// find free voice
		    {
			    hwv = getvoice(ch,no);
			    if (hwv == NUMVOICES) return;		// no free voices
			    freevoice[hwv] = no;					// mark voice as in-use
             		    channelnumvoice[ch]++;
		    }
		    chnlref[hwv] = ch;						   // set voice reference
		    voiceref[ch][no][1]=hwv;				   // remember hardware voice
		    _pbvalue[hwv] = chnlpbvalue[ch];		// set pitch bend value
		    _modvalue[hwv]= modvalue[ch];			// set modulation value

          if (ch==9)
          {
             voicepriority[hwv]=drumpriority[no];
             hw_noteon(hwv,drumnote[no],ve,tone);
          }
          else
          {
             voicepriority[hwv]=channelpriority[ch];
             hw_noteon(hwv,no,ve,tone);
          }
		}

	} else										/* noteoff event */
	{
		if ((hwv=voiceref[ch][no][0])!=255)
		{
         channelnumvoice[ch]--;
			hw_noteoff(hwv);
			voiceref[ch][no][0]=255;			// mark as noteoff'ed
         chnlref[hwv]=16;
			freevoice[hwv] = 255;
		}
		if ((hwv=voiceref[ch][no][1])!=255)
		{
         channelnumvoice[ch]--;
			hw_noteoff(hwv);
			voiceref[ch][no][1]=255;			// mark as noteoff'ed
         chnlref[hwv]=16;
			freevoice[hwv] = 255;
		}
	}

   {
      int t=0,t2=0;
      gotoxy(41-NUMVOICES,12);
      for (i=0;i<NUMVOICES;i++)
      {
         textcolor(chnlref[i]);
         if (freevoice[i]!=255) outtext("*"); else outtext(" ");
      }


      for (i=0;i<16;i++)
          t += channelnumvoice[i];
      for (i=0;i<NUMVOICES;i++)
          if (freevoice[i]!=255) t2++;

      if (t2!=t)
      {
         printf("ERROR : %d voices used by chnlnumvoice, %d reported by freevoice.",t,t2);
         getch();
      }
   }
}

void processpitchbendmsg(unsigned char chnl, unsigned char lsb, unsigned char msb)
{
	unsigned	pbvalue;
	int		hwv;

	pbvalue = (msb << 7) + lsb;

	chnlpbvalue[chnl] = pbvalue-0x2000;

	/*	find the voices which need to be pitch bent */

	for (hwv=0;hwv<NUMVOICES;hwv++)
		if (chnlref[hwv] == chnl)
		{
			_pbvalue[hwv]     = pbvalue-0x2000;

			/* f�lgende skal ikke g�res i praxis - men automatisk opdateres
			   via runtime kalkulation ... m�ske - m�ske for tidskr�vende.
			   M�ske skal der bare sendes en message til driveren, der for-
			   t�ller, at der er sket en �ndring i pitch bend, s� f-number
			   automatisk bliver opdateret n�ste gang den "kommer forbi".. */

			hw_pbchange(hwv);
		}
}

void processmodulationmsg(unsigned char chnl, unsigned char value)
{
	unsigned char hwv;

	modvalue[chnl] = value;

	for (hwv=0;hwv<NUMVOICES;hwv++)
		if (chnlref[hwv] == chnl)
		{
			_modvalue[hwv] = value;
		}
}

void processresetctrlsmsg(unsigned char chnl)
{
	chnlpbvalue[chnl]  = 0;
	modvalue[chnl] = 0;
}

void processvolumemsg(unsigned char chnl, unsigned char value)
{
	chnlvolumevalue[chnl]  = value;
}

void processexpressionmsg(unsigned char chnl, unsigned char value)
{
	chnlexpressionvalue[chnl]  = value;
}

void inittables(void)
{
	int	c,n;

	/* initialize voice number + channel reference */

	for (c=0;c<16;c++)
	{
      chnlvolumevalue[c]=chnlexpressionvalue[c]=100;
      chnlpbvalue[c]=0x2000;

   	for(n=0;n<128;n++)
			voiceref[c][n][0] = voiceref[c][n][1] = 255;
   }
	for (n=0;n<NUMVOICES;n++)
	{
      freevoice[n] = 255;
   	chnlref[n]=16;				/* remove channel reference */
   }
}

int	emuinit(void)
{
    inittables();

	/* initialize pitch bend range to default */

	_pbsens = 12; // default pitch bend sens of MT-32

	return (hw_emuinit());
}

/*	Denne funktion kaldes i stedet for putdat() for MIDI-emulation */
/*	Fra MIDI-emulatorens synsvinkel skulle funktionen have heddet "getdat" */

void emuputdat(unsigned char value)
{
	/*	What's expected ? */

	static unsigned char midicmd=0;
	unsigned char	valueready = 1;

	if (expected == EXP_ANYTHING)
	{
	/*	Possible messages:
			Any message header.
			Any message without header.
	*/

	/*	Check for 8 bit commands */

		valueready=0;

		if (value == CMD_ACTIVE_SENSING)
			return;								/* ignore */
		else
		if (value == CMD_EXCLUSIVE)
		{
			expected = EXP_EXCLUSIVE_END;
			return;
		} else

	/*	Check for events without header */

		if (value < 0x80) 						/* same as last cmd */
		{
			valueready=1;
			cmd = midicmd;
		}
		else cmd = midicmd = value;

		chnl = midicmd & 0xf;

		midicmd = midicmd & 0xf0;

		switch(midicmd)
		{
			case CMD_NOTEOFF:
				expected = EXP_NOTEOFF_NOTE;
				break;

			case CMD_NOTE:
				expected = EXP_NOTE;
				break;

			case CMD_CC:
				expected = EXP_CC_MSG;
				break;

			case CMD_POLY_KEY_PRES:
				expected = EXP_NOTE;
				break;

			case CMD_PROGRAM_CHANGE:
				expected = EXP_PROGRAM;
				break;

			case CMD_CHANNEL_PRES:
				expected = EXP_CHANNEL_PRES;
				break;

			case CMD_PITCH_BEND:
				expected = EXP_PITCH_BEND_LSB;
				break;

			default:;	/* non-standard; nothing to do but ignore */
		}
	}
	if (valueready)
		switch(expected)
		{
			case EXP_NOTE:
				note = value;
				expected = EXP_VELOCITY;
				break;

			case EXP_VELOCITY:
				velocity = value;
				expected = EXP_ANYTHING;
				processnotemsg(chnl,note,velocity);
				break;

         case EXP_NOTEOFF_NOTE:
            note = value;
            expected = EXP_NOTEOFF_VELOCITY;
            break;

         case EXP_NOTEOFF_VELOCITY:
            velocity = value;
            expected = EXP_ANYTHING;
            processnotemsg(chnl,note,0); // noteoff velocity not supported
            break;

			case EXP_EXCLUSIVE_END:
				if (value == CMD_EXCLUSIVE_END)
					expected = EXP_ANYTHING;
				break;

			case EXP_CC_MSG:
				cc = value;
				expected = EXP_CC_VALUE;
				break;

			case EXP_CC_VALUE:
				switch(cc)
				{
				case CM_ALL_NOTES_OFF:
					processallnotesoffmsg(chnl);
					break;

				case CM_ALL_SOUNDS_OFF:
					processallsoundsoffmsg(chnl);
					break;

				case CC_BANK_SELECT:
					gsbank[chnl] = value;
					break;

				case CM_RESET_ALL_CTRLS:
					processresetctrlsmsg(chnl);
					break;

				case CC_MODULATION:
					processmodulationmsg(chnl,value);
					break;

	               case CC_VOLUME:
        	          processvolumemsg(chnl,value);
                	  break;
	
        	       case CC_EXPRESSION:
                	  processexpressionmsg(chnl,value);
	                  break;

	               case CC_RPN_LSB:
        	          rpnlsb = value;
                	  break;

	               case CC_DATA_ENTRY_MSB:
        	          if (rpnlsb==0) // entry of pitch bend sensitivity
                	     _pbsens = value;
	                  break;

	               default:;// control change messages not accounted for
        	                // include PANPOT (not supported by mono hardware)
		}
		expected = EXP_ANYTHING;
		break;

		case EXP_PROGRAM:
			program[chnl] = value;
			expected = EXP_ANYTHING;
			break;

		case EXP_PITCH_BEND_LSB:
			databyte = value;
			expected = EXP_PITCH_BEND_MSB;
			break;

		case EXP_PITCH_BEND_MSB:
			expected = EXP_ANYTHING;
			processpitchbendmsg(chnl, databyte,value);
			break;

		default:
			expected = EXP_ANYTHING;
	}
}
