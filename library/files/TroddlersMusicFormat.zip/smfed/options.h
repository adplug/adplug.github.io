void recordoptions(struct sequence *s,int autoval);
