#ifndef SCRWIN_H
#define SCRWIN_H

#include "node.h"

struct scrwindow
{
	struct ln_node ln;
	int left,top,right,bottom;
	char **strings;
	char *title;
	int fground,bground;/* colors */
	int	topstring,active;
	int	 *hilited;/* set to NULL to disable hotkeys */
	char *hotkeys;/* the same here */

/****** auto-initialized **************************/
	int width,height,numstr;
	void *below;
};

#define KBDENTRY_INTEGER
#define KBDENTRY_STRING

struct kbdentry
{
	struct ln_node ln;
	int x,y;
	char *value;
	char *title;
	int fground,bground;
	int type;			/* 0 = text, 1 = integer */
	int maxlen;			/* max length of value */
};

void openscrwin(struct scrwindow *);
void closescrwin(struct scrwindow *);
int selectscrwin(struct scrwindow *,void (*live)());
void drawstrings(struct scrwindow *);

int	numinput(char *,int,int,int);
int strinput(char *,int,char *);
void outmsg(char *);
int	confirm(char *);
void scrwinputs(struct scrwindow *,int x,int y,char *);
#endif
