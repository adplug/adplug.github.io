#include <stdio.h>
#include <io.h>


FILE *stream;
FILE *stream1;

typedef struct {
char name[14];
long p,l;
} fthing;

fthing files[500];

main()
    {
    long d;
    char s[14];
    long p,l;
    int good;
    int i,j;
    long total;
    int fls;
    unsigned int di;
    char fn[80];
    unsigned char ch;
    long tot2;
    char fn1[80];
    printf("What filename (results will be dumped into dump/ --must exist)? ");
    scanf("%s",fn1);

    stream=fopen(fn1,"rb");
     fread(&d,3,1,stream);
    good=1;
    total=0;fls=0;tot2=0;
    while (good==1)
        {
	for (i=0; i<14; i++) s[i]=0;
	 fread(s,1,12,stream);
	fread(&p,1,4,stream);
	 fread(&l,1,4,stream);
    fread(&di,1,2,stream);

	 good=0;
	 for (i=0; i<14; i++) if (s[i]=='.') good=1;
        if (good==1)
            {
        printf ("file: %s, pos: %ld, len: %ld, ?: %x\n",s,p,l,di);
	    total+=l;
        tot2+=di;
	    sprintf(files[fls].name,s);
	    files[fls].p=p;
	    files[fls].l=l;
        fls++;
            }
	}
 printf ("total files: %d, size: %ld, ?: %ld\n",fls,total,tot2);
    fclose(stream);

    stream=fopen("fuzzy0.res","rb");
    for (i=0; i<fls-1; i++)
	{
	sprintf(fn,"dump\\%s",files[i].name);
	stream1=fopen(fn,"wb");
	fseek(stream,files[i].p,SEEK_SET);
	/*
    fread(&d,1,4,stream);
    printf("%s %ld\n",files[i].name,d);
    */
	for (l=0; l<files[i].l; l++)

		{
		ch=fgetc(stream);
        fputc(ch,stream1);

		 }
	fclose(stream1);
	 }
   fclose(stream);
    }

