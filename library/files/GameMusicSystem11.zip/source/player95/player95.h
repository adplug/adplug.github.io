// Windows 95 player program header file (PLAYER95.H)
//
// Written 1996, 1997 by Roland Acton - public domain.
//
// This file is part of the Game Music System 1.1 distribution.

// Things relating to the Win95 player program.

#ifndef INCLUDED_PLAYER95
#define INCLUDED_PLAYER95

#define IDD_SB_BASE 100
#define IDD_VOLUME 101
#define IDD_SOUNDSYSTEM_ADLIB 102
#define IDD_SOUNDSYSTEM_SB 103
#define IDD_SOUNDSYSTEM_SBPRO1 104
#define IDD_SOUNDSYSTEM_SBPRO2 105

#define IDD_SB_BASE_TEXT 200
#define IDD_SOUNDSYSTEM_TEXT 201

#define ID_TOOLBAR 300
#define ID_TOOLBAR_BITMAP 301

#define IDM_LOAD 400
#define IDM_ABOUT 401
#define IDM_EXIT 402
#define IDM_PAUSE 403
#define IDM_PLAY 404
#define IDM_STOP 405

LRESULT CALLBACK WindowFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DialogFunc(HWND, UINT, WPARAM, LPARAM);
VOID CALLBACK TimerFunc(HWND hwnd, UINT msg, UINT TimerID,
  DWORD SysTime);

#ifdef COMPILING_PLAYER95
  static char WinName[] = "Main Window";
  static char open_file_name[255];
  static int is_module_loaded;
  static int is_song_paused;
  HINSTANCE player_instance_handle;
  HWND player_toolbar;

  TBBUTTON play_buttons[] =
    {{0, IDM_PAUSE, TBSTATE_ENABLED, TBSTYLE_BUTTON, {0, 0}, 0, 0},
     {1, IDM_PLAY, TBSTATE_ENABLED, TBSTYLE_BUTTON, {0, 0}, 0, 0},
     {2, IDM_STOP, TBSTATE_ENABLED, TBSTYLE_BUTTON, {0, 0}, 0, 0}};
/*
  TBBUTTON play_buttons[] =
    {{0, IDM_PAUSE, TBSTATE_INDETERMINATE, TBSTYLE_CHECK, 0, 0},
     {1, IDM_PLAY, TBSTATE_ENABLE, TBSTYLE_BUTTON, 0, 0},
     {2, IDM_STOP, TBSTATE_ENABLE, TBSTYLE_BUTTON, 0, 0}};
*/
#endif

#endif   // #ifndef INCLUDED_PLAYER95
