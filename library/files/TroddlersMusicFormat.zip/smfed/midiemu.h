
int	emuinit(void);		/*  initialize everything needed for midiemu to
								handle MIDI data */

void	emuputdat(unsigned char);	/*	MIDI output routine. This is where MIDI data
								should be sent to the emulator */

