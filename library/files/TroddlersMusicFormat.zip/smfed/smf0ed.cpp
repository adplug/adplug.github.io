#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include <asm.h>
#include <dir.h>
#include <string.h>
#include <mem.h>
#include <alloc.h>
#include <io.h>
#include <asm.h>
#include <ctype.h>
//#include "globdat.h"
#include "patchdat.h"
#include "mouse.h"
#include "graph.h"
#include "adlib.h" // struct tinstrument
#include "text.h"
#include "drumset.h"

#define getword(f) ((getc(f)<<8)+getc(f))
#define SCRW 320

extern int _echochannel; // from MPU.C

extern volatile long tick;

int _tempo=1;

extern unsigned _stklen = 12000;

extern "C"
{
   void settimerint();
   void restoretimerint();

   void setmpuint();
   void restorempuint();

   void thru();

   void emuinit(void);
   void emuputdat(unsigned char);
   void panic(void);

   int hw_loadinstruments(char far *);
   int hw_saveinstruments(char far *);
   void loadpatchdata(const char *);
   void savepatchdata(const char *);

   FILE *fileopen(char*,char*);
   void fileclose(FILE*);
}

const char emptyline[] = "                                        ";
char xorName[MAXPATH]; // name of file being edited

const char *notenames[] =
{
   "C",
   "C#",
   "D",
   "D#",
   "E",
   "F",
   "F#",
   "G",
   "G#",
   "A",
   "A#",
   "B"
};

int numVarBytes(unsigned long value)
// return number of bytes required to store value in 7-bit variable length
// integer format
{
   if (value<=0x7fL) return 1;
   if (value<=0x3fffL) return 2;
   if (value<=0x1fffffL) return 3;
   if (value<=0xfffffffL) return 4;
   return 5;
}

unsigned char huge *putVLValue(unsigned char huge *p,unsigned long value)
// put variable length integer value onto stream p and return the position
// of stream p after the insertion.
{
   int i;
   unsigned char c=0;
   int nb = numVarBytes(value);

   for (i=nb-1;i>=0;i--)
   {
      *(p+i)=(unsigned char)(value&0x7f)|c;
      c=0x80;
      value >>= 7;
   }
   return p+nb;
}


struct MIDIEvent
{
   long time;
   unsigned char data[3];
};

unsigned char huge *midiData; // points to original midi file data
unsigned char huge *xorData;  // points to xor midi file data
long midiLength;
long xorLength;

int maxvoices=9;
static Mouse mouse;
extern int directvideo=0;
int ticksperquarter;
int quit=0;

class View
{
public:
   int minx,miny,maxx,maxy;
   View(int x1,int y1,int x2,int y2)
   {
      minx=x1;miny=y1;
      maxx=x2;maxy=y2;
   }
   virtual void processKey(int x,int y,int key1,int key2) = 0;
   virtual void processMouse(int x,int y,int buttons) = 0;
   virtual void redraw()=0;
};

class Button : public View
{
public:
   const char *tx;
   int mouseReleased;
   Button(int x1,int y1,const char *text) : View(x1,y1,(strlen(text)*8)+16,y1+16)
   {
      mouseReleased=0;
      tx=text;
      minx=x1;
      miny=y1;
      maxx=x1+(strlen(text)*8)+16;
      maxy=y1+16;
      redraw();
   }
   virtual void pressed();
   void processMouse(int,int,int);
   void redraw();
};

void Button::pressed()
{
}

void Button::redraw()
{
   horizline(minx,miny,maxx,15);
   horizline(minx,maxy,maxx,15);
   vertline(minx,miny,maxy,15);
   vertline(maxx,miny,maxy,15);
   gotoxy((minx+1)>>3,miny>>3);
   outtext(tx);
}

void Button::processMouse(int,int,int but)
{
   if (but&1)
   {
      if (mouseReleased==1)
      {
         mouseReleased=0;
         pressed();
      }
   } else
   {
      if (mouseReleased==0) mouseReleased=1;
   }
}


class MIDIView : public View
{
public:
   MIDIView(int x1,int y1,unsigned char huge *mdata,unsigned long len);
   ~MIDIView();

   int channelon[16]; // playback filter by MIDI channel

   int dirty;

   unsigned char vertdata[128];  // data of current pixel column
   unsigned char leftvertdata[128];  // data on left boundary of display

   long length;

   long timeat;
   long postime;

   long markleft,markright;

   unsigned char huge *midiData;
   unsigned char huge *pos;
   unsigned char huge *pickedEvent;

   long pickTime;       // event time of picked event
   int  pickRunStat;    // running status of picked event
   int  pickChannel;    // channel of picked event

   int posrunstat;
   int runstat;
   int posvoiceson;

   // parameters to remember for left marker loop

   unsigned char huge *markpos;
   long marktime;
   int markrunstat;


   int posx;            // view xpos of postime

   long t0;             // starting tick of play
   long timestart;      // tune time when start of play
   unsigned char huge *cp;// pointer to current tune position in play mode


   int numvoiceson;     // number of keys currently DOWN
   int topnote;

   int zoom;

   // old'erne checkes for om der skal redraw'es

   long oldtime;
   int oldtopnote;
   int oldzoom;
   int oldkey;

   void plotvert(int x); // plot en lodret linie
   void rewind(void);    // spol helt tilbage
   void wind(void);      // spol frem til timeat
   unsigned char huge *searchEvent(int,int);//search for event
   void redraw(void);    // gentegn
   void processMouse(int x,int y, int buttons); // relative mouse position
   void processKey(int x,int y,int key1,int key2);
   void insertMIDIEvent(unsigned long timeSource,
                        int srcEvLen, unsigned char data[]);
   void copyNote(unsigned char huge *src, MIDIView *dest);
   void deleteEvent();// delete picked event
   int play(MIDIView *xor);
   void resetPlay();
};

MIDIView *mainView; // original file
MIDIView *xorView;  // xor-file



void MIDIView::resetPlay()
{
   cp = pos;
   timestart = timeat;
   t0 = tick;
}


int MIDIView::play(MIDIView *)
// returns a code indicating cause of return:
// 0 = any key pressed
// 1 = end of tune
// 2 = update of screen needed
// 3 = mark loop point reached
{
   long timeVal;
   unsigned char c;
   unsigned char data[3];
   static unsigned char runstat;
   int scrnspan;
   int datalen;
   int rc=0; // return code

   scrnspan = 320*(1<<zoom);

   do
   {
      timeVal=0L;
      for(;;) {
         c = *cp++;
         timeVal += c&0x7f;
         if (c<0x80) break;
         timeVal <<= 7;
      }
      if (cp>=midiData+length)
      {
         rc=1;
         break; // end of file
      }
      c=*cp++;
      if (c==0xff) // meta-event
      {
         int t=*cp++;
         int l=*cp++;
         cp += l;
         continue;
      }

      if(c<0x80) // use running status
      {
         data[0] = runstat;
         data[1] = c;
         if ((data[0]&0xf0)==0xc0 || (data[0]&0xf0)==0xd0) datalen = 2;
         else
         {
            data[2] = *cp++;
            datalen = 3;
         }
      } else
      {
         data[0] = c;
         data[1] = *cp++;
         if ((data[0]&0xf0)==0xc0 || (data[0]&0xf0)==0xd0) datalen = 2;
         else
         {
            data[2] = *cp++;
            datalen = 3;
         }
      }
      if (timeVal)
      {
         timeat += timeVal;
         if (timeat>=markright && markright > markleft)
         {
            rc=3;
            break;
         }
         while ((tick-t0)*_tempo<timeat-timestart)
         {
//            int xpi = (int)((((tick-t0)*_tempo)-(postime-timestart))>>zoom);
//            horizline(minx,miny+80,xpi,0);
//            putpixel(xpi,miny+80,14);
//            thru();
         }
      }
      runstat=data[0];
      if (channelon[data[0]&0xf])
      {
         switch(data[0]&0xf0)
         {
            default:
            for (int n=0;n<datalen;n++)
               emuputdat(data[n]);
         }
      }
      if (postime+scrnspan<timeat)
      {
         rc=2;
         break;
      }
      if (kbhit())
      {
         rc=-1;
         break;
      }
      thru();
   } while (rc==0);
   spilslut:;
   if (rc==-1) rc=0;
   return rc;
}


extern unsigned char program[16]; // from MIDIEMU.C
extern struct tinstrument *_insdata;

int playing=1;

// editing drum setup table


void editdrumsetup(void)
{
   char sl[100];
   static int x=0,y=0;
   int i,cont=1;

   for (i=0;i<10;i++)
   {
      gotoxy(1,13+i);
      outtext(emptyline);
   }

   gotoxy(1,13);
   textcolor(DARKGRAY);
   outtext("Drum patch/key setup");

   do
   {
      sprintf(sl,"Key %-2s-%2d Tone %-3d Key %-2s-%2d Pri %-3d",
         notenames[y%12],y/12,drumins[y],notenames[drumnote[y]%12],
         drumnote[y]/12,drumpriority[y]);

      textcolor(LIGHTRED);
      gotoxy(1,15);
      outtext(sl);

      switch(x)
      {
         case 0:
            gotoxy(4,15);
            break;

         case 1:
            gotoxy(15,15);
            break;

         case 2:
            gotoxy(23,15);
            break;

         case 3:
            gotoxy(33,15);
            break;
      }
      textcolor(LIGHTGREEN);
      outtext(">");
nodraw:;
      int rc;
      if (playing) rc = mainView->play(xorView);
      else rc=0;
      if (rc==0 && kbhit()) do
      {
         int c = getch();

         switch(c)
         {
            case ' ':
               playing=!playing;
               if (!playing) panic();
               else
               {
                  mainView->redraw();
                  mainView->resetPlay();
               }
               break;

            case '+':
               if (x==0) {if (y<127)y++;}
               else
               {
                  if (x==1) drumins[y]++;
                  else if (x==2) drumnote[y]++;
                  else if (x==3) drumpriority[y]++;
                  xorView->dirty=1;
               }
               break;

            case '-':
               if (x==0) {if (y)y--;}
               else
               {
                  if (x==1) drumins[y]--;
                  else if (x==2) drumnote[y]--;
                  else if (x==3) drumpriority[y]--;
                  xorView->dirty=1;
               }
               break;

            case 0:
               switch(getch())
               {
                  case 0x4d: //r
                     if (x<3)x++;
                     break;

                  case 0x4b: //l
                     if(x)x--;
                     break;

                  case 0x48: //u
                     if (y)y--;
                     break;

                  case 0x50: //d
                     if (y<127)y++;
                     break;
               }
               break;

            case 13: // enter: confirm changes and return
            case 27:
               return;

            default:;
         }
      } while (0);
      else if (rc==1) // end of tune
      {
         cont = 0;
      } else if (rc==2)
      {
         mainView->redraw();
         goto nodraw;
      } else if (rc==3) // loop
      {
         panic();
         mainView->pos = mainView->markpos;
         mainView->posrunstat = mainView->markrunstat;
         mainView->postime = mainView->marktime;
         mainView->timeat = mainView->markleft;
         mainView->redraw();
         mainView->resetPlay();
         goto nodraw;
      }
      thru();
   } while (cont);
   xorView->redraw();
   return;
}


const char *insexp[] =
{
   "KSL#0","KSL#1","MUL#0","MUL#1","FBK#0","FBK#1","ATK#0","ATK#1",
   "SUS#0","SUS#1","SSF#0","SSF#1","DCY#0","DCY#1","REL#0","REL#1",
   "OUT#0","OUT#1","AMP#0","AMP#1","VIB#0","VIB#1",
   "ENV#0","ENV#1","COMBI","WFM#0","WFM#1","LFO-D",
   "LFO-R","DETUN","KOD#0","KOD#1","KOS#0","KOS#1",
   "VEL#0","VEL#1","TVP-D","TVP-R","COARS","PAD#1"
};

// editing the patch part

void editpatchpart(int part,int chnl)
{
   char sl[100];
   static int x=0,y=0;
   int i,cont=1;

   do
   {
      unsigned char *xv;

      xv = (unsigned char *)(&_insdata[part]);
      for (i=0;i<40;i+=4)
      {
         textcolor(chnl);
         gotoxy(1+((i%4)*10),13+(i/4));

         sprintf(sl,
         "%-6s%-3d %-6s%-3d %-6s%-3d %-6s%-3d ",
            insexp[i],*xv,
            insexp[i+1],*(xv+1),
            insexp[i+2],*(xv+2),
            insexp[i+3],*(xv+3)
         );
         outtext(sl);
         xv += 4;
      }

      textcolor(LIGHTGREEN);
      gotoxy(6+(x*10),13+y);
      outtext(">");
nodraw:;
      int rc;
      if (playing) rc = mainView->play(xorView);
      else rc=0;
      if (rc==0 && kbhit()) do
      {
         xv = (unsigned char *)(&_insdata[part]);
         xv += x+(y*4);

         int c = getch();

         switch(c)
         {
            case ' ':
               playing=!playing;
               if (!playing)panic();
               else
               {
                  mainView->redraw();
                  mainView->resetPlay();
               }
               break;
            case '+':
               (*xv)++;
               xorView->dirty=1;
               break;
            case '-':
               (*xv)--;
               xorView->dirty=1;
               break;
            case 0:
               switch(getch())
               {
                  case 0x4d: //r
					 if (x<3)x++;
					 break;
				  case 0x4b: //l
					 if(x)x--;
					 break;
				  case 0x48: //u
					 if (y)y--;
					 break;
				  case 0x50: //d
					 if (y<9)y++;
					 break;
			   }
			   break;

			case 13: // enter: confirm changes and return
			case 27:
			   return;

			default:;
		 }
	  } while (0);
	  else if (rc==1) // end of tune
	  {
		 cont = 0;
	  } else if (rc==2)
	  {
		 mainView->redraw();
		 goto nodraw;
	  } else if (rc==3) // loop
	  {
		 panic();
		 mainView->pos = mainView->markpos;
		 mainView->posrunstat = mainView->markrunstat;
		 mainView->postime = mainView->marktime;
		 mainView->timeat = mainView->markleft;
		 mainView->redraw();
		 mainView->resetPlay();
		 goto nodraw;
	  }
	  thru();
   } while (cont);
   xorView->redraw();
   return;
}

extern unsigned char channelmaxvoice[]; // defined in MIDIEMU.C
extern unsigned char channelpriority[]; // defined in MIDIEMU.C


// editing the patch setup

void editpatchsetup(void)
{
   static int x=0,y=0;
   int i,cont=1;
   char sl[100];

   mouse.hide();
   panic();

   mainView->redraw();
   mainView->resetPlay();

   gotoxy(1,12);
   outtext(emptyline);
   textcolor(LIGHTRED);
   gotoxy(1,12);
   outtext("ESC to exit edit/play mode");
   do
   {
   gotoxy(1,13);textcolor(LIGHTGREEN);
   outtext("\
Chnl   Patch Part A  Part B  Res   Pri");
	  for (i=1;i<10;i++)
	  {
		 textcolor(i);
		 gotoxy(1,13+i);
		 {
			sprintf(sl,"%-7d%-6d%-8d%-8d%-5d%-5d",i,program[i],
			   _patchtable[program[i]].ins1,
			   _patchtable[program[i]].ins2,
			   channelmaxvoice[i],channelpriority[i]);
			outtext(sl);
		 }
	  }
	  textcolor(LIGHTGREEN);
	  gotoxy((x*7)+6,y+14);
	  outtext(">");
	  _echochannel=y+1;
nodraw:;
	  int rc;
	  if (playing) rc = mainView->play(xorView);
	  else rc=0;
	  if (rc==0 && kbhit()) do
	  {
		 int c = getch();

		 switch(c)
		 {
			case 27:
			   cont=0;
			   break;
			case ' ':
			   playing=!playing;
			   if (!playing) panic();
			   else
			   {
				  mainView->redraw();
				  mainView->resetPlay();
			   }
			   break;

			case '+':
			   xorView->dirty=1;
			   if (x==1)
				  _patchtable[program[y+1]].ins1++;
			   else if (x==2)_patchtable[program[y+1]].ins2++;
			   else if (x==3) channelmaxvoice[y+1]++;
               else if (x==4) channelpriority[y+1]++;
			   else if (x==0) if (y==8) program[y+1]++;
			   break;
			case '-':
			   xorView->dirty=1;
			   if (x==1)
				  _patchtable[program[y+1]].ins1--;
			   else if (x==2) _patchtable[program[y+1]].ins2--;
			   else if (x==3) channelmaxvoice[y+1]--;
			   else if (x==4) channelpriority[y+1]--;
			   else if (x==0) if (y==8) program[y+1]--;
			   break;
			case 0:
			   switch(getch())
			   {
              case 59: // f1
                if (_tempo<20)_tempo++;
                break;

              case 60: // f2
                if (_tempo) _tempo--;
                break;

				  case 0x4d: //r
					 if (x<4)x++;
					 break;
                  case 0x4b: //l
                     if (x) x--;
                     break;
                  case 0x48: //u
                     if (y)y--;
                     break;
                  case 0x50: //d
                     if (y<8)y++;
                     break;
               }
               break;

            case 13: // enter: edit patch part
                  if (x==1) editpatchpart(_patchtable[program[y+1]].ins1,y+1);
                  else if (x==2) editpatchpart(_patchtable[program[y+1]].ins2,y+1);
                  else if (y==8) editdrumsetup();
               break;

            default:
               if (c>='1'&&c<='8') y=c-'1';

         }
      } while (0);
      else if (rc==1) // end of tune
      {
         cont = 0;
      } else if (rc==2)
      {
         mainView->redraw();
         goto nodraw;
      } else if (rc==3) // loop
      {
         panic();
         mainView->pos = mainView->markpos;
         mainView->posrunstat = mainView->markrunstat;
         mainView->postime = mainView->marktime;
         mainView->timeat = mainView->markleft;
         mainView->redraw();
         mainView->resetPlay();
         goto nodraw;
      }
      thru();
   } while (cont);
   panic();
   gotoxy(1,12);
   outtext(emptyline);
   mainView->redraw();
   xorView->redraw();
   mouse.show();
}







MIDIView::MIDIView(int x1,int y1,unsigned char huge *md,unsigned long len) :
   View(x1,y1,x1+320,y1+80)
{
   midiData = md;
   length = len;
   topnote=32;
   zoom=3;
   markleft=markright=-1;
   pickedEvent=0;
   timeat=0;
   dirty=0;
   for(int i=0;i<16;i++)channelon[i]=1;
   rewind();
   redraw();
}

void MIDIView::deleteEvent()
// delete the event beginning at pickedEvent
{
   unsigned char huge *sp = pickedEvent;
   unsigned char c;
   long value;
   long oldTime,nextTime;
   int dataLen, timeLen, eventLen;
   int nextLen, nextTimeLen;
   int oldusers=0; // event to delete uses running status of previous event

   unsigned char data[3];

   // get length until event to delete

   value=0L;
   for (;;)
   {
      c = *sp++;
      value += c&0x7f;
      if (c&0x80) value <<= 7;
      else break;
   }
   oldTime = value;
   timeLen = (int)(sp-pickedEvent);

   // read event to delete

   unsigned char huge *po;

   po = sp;

   c=*sp++;
   if (c<0x80)
   {
      data[1]=c;
      data[0]=pickRunStat;
      oldusers=1; // uses running status
   } else
   {
      data[0]=c;
      data[1]=*sp++;
   }
   if (data[0]!=0xe0 &&
       data[0]!=0xc0)
   {
       data[2]=*sp++;
       dataLen = 3;
   }
   else dataLen = 2;

   // length of data packet

   eventLen = (int)(sp-po);

   pickRunStat = data[0];

   // read time from event to delete until next event

   unsigned char huge *spp = sp;

   value=0L;
   for (;;)
   {
      c = *sp++;
      value += c&0x7f;
      if (c&0x80) value <<= 7;
      else break;
   }
   nextTime = value;
   nextTimeLen = (int)(sp-spp);

   // if next event uses running status of the deleted event, insert an extra
   // byte to make room for a command byte

   c = *sp;
   if (c<0x80) // uses running status
   {
      if (!oldusers) // if old uses rs too, don't squeeze 1 byte
      {
         *sp = pickRunStat;
      }
   } else sp++; // uses not running status

   long newTime = oldTime+nextTime;

   unsigned char huge *pp;

   pp = putVLValue(pickedEvent, newTime);

   if (sp > pp) // squeeze only if space is there
   {
      while(pp < midiData+length)
      {
         *pp++ = *sp++;
      }
      midiLength -= (int)(sp-pp);
   }
   redraw();
}

void MIDIView::insertMIDIEvent(unsigned long timeSource,
                               int srcEvLen, unsigned char data[])
// insert event identified by srcEvLen bytes in the array specified by data
// into this at the absolute time specified by timeSource.
// Does not redraw the MIDIView after inserting.
{
   unsigned char c;
   unsigned long value;
   unsigned char huge *sp;

   dirty=1;

   // wind file from zero until time equal to timeSource.

   timeat = timeSource;
   if (timeat>postime)wind();
   else if (timeat<postime)
   {
      rewind();
      wind();
   }

   unsigned char huge *dp;
   int dTimeLen; // number of bytes required to store time value

   dp = sp = pos;

   value=0L;
   for(;;) {
      c = *sp++;
      value += c&0x7f;
      if (c&0x80) value <<= 7;
      else break;
   }
   dTimeLen = (int)(sp-dp); // length of time descriptor

   unsigned long l1,l2;

   // l1 = new time value at pos

   l1 = timeSource - postime;
   l2 = value - l1; // remaining time from newly inserted to next event

   // calculate number of bytes required to store the event to insert

   int nb1,nb2;

   nb1 = numVarBytes(l1)+srcEvLen;
   nb2 = numVarBytes(l2);
   nb1 += nb2-dTimeLen;

   // make space for the new event in this

   unsigned char huge *p1,huge *p2,huge *pend;

   p1 = midiData+length;
   p2 = p1 + nb1;

   pend = pos;

   while(p1>=pend)
   {
      *p2-- = *p1--;
   }

   length += nb1;

   // insert the new event time into this

   p1 = putVLValue(pos,l1);

   // insert the new event into this

   *p1++=data[0];
   *p1++=data[1];
   if (srcEvLen==3)*p1++=data[2];

   // put the new time of the old event into this

   putVLValue(p1,l2);

}

void MIDIView::copyNote(unsigned char huge *md, MIDIView *dest)
// copies note beginning with note on at md and the corresponding note off
// event to dest. dest is assumed to point to the beginning of the file to
// which the event is to be copied. The event is inserted in dest at the same
// point of time as it is in md.
{
   // remove note on from md

   long value;
   long timeSource;
   unsigned char c;
   unsigned char data[3];

   unsigned char huge *sp;
   int srcEvLen;                // length of old event

   sp = md;

   // get time before event to remove

   value=0L;
   for(;;) {
      c = *sp++;
      value += c&0x7f;
      if (c&0x80) value <<= 7;
      else break;
   }
   timeSource = value+pickTime;

   c=*sp++;

   if (c<0x80) // use running status of pickedEvent ?
   {
      data[1]=c; // c is data byte
      c = pickRunStat|pickChannel;
      if ((c&0xf0)==0xd0 || (c&0xf0)==0xc0)
      {
         srcEvLen=2;
      } else
      {
         data[2] = *sp++;
         srcEvLen=3;
      }
   } else
   {
      if ((c&0xf0)==0xd0 || (c&0xf0)==0xc0)
      {
         data[1] = *sp++;
         srcEvLen=2;
      } else
      {
         data[1] = *sp++;
         data[2] = *sp++;
         srcEvLen=3;
      }
   }
   data[0]=c;

   int key = data[1];

   dest->insertMIDIEvent(timeSource, srcEvLen, data);



   // find the note off event for the inserted noteon event

   runstat = pickRunStat;
   int channel = pickChannel;

   for (;;)
   {
      value=0L;
      for(;;) {
         c = *sp++;
         value += c&0x7f;
         if (c&0x80) value <<= 7;
         else break;
      }
      if (sp>=midiData+length)
      {
         sound(1000);
         delay(100);
         nosound();
         dest->timeat=timeat; // jump to same place as source
         dest->redraw();
         return; // error: no matching noteoff event
      }
      timeSource += value;

      c=*sp++;
      if (c==0xff) // meta-event
      {
         int t=*sp++;
         int l=*sp++;
         sp += l;
         continue;
      }

      if (c<0x80)
      {
         data[1]=c; // c is data byte
         c = runstat|channel;
         if ((c&0xf0)==0xd0 || (c&0xf0)==0xc0)
         {
            srcEvLen=2;
         } else
         {
            data[2] = *sp++;
            srcEvLen=3;
         }
      } else
      {
         if ((c&0xf0)==0xd0 || (c&0xf0)==0xc0)
         {
            data[1] = *sp++;
            srcEvLen=2;
         } else
         {
            data[1] = *sp++;
            data[2] = *sp++;
            srcEvLen=3;
         }
      }
      data[0]=c;
      runstat=c;
      channel=c&0xf;

      if (channel==pickChannel && data[1]==key)
      {
         if ((c&0xf0)==0x80 || (((c&0xf0)==0x90) && data[2]==0))
         {
            dest->insertMIDIEvent(timeSource, srcEvLen, data);
            dest->timeat=timeat; // jump to same place as source
            dest->redraw();
            while (mouse.pos()&0x40000000L);
            return; // OK
         }
      }
   }
}

#pragma argsused
void MIDIView::processMouse(int mx,int my,int)
{
   char sl[100];

   if (mx<30)
      timeat-= ((30-mx)<<zoom);
   else if (mx>320-30)
      timeat += (30-(320-mx))<<zoom;

   int key=127-(topnote+my);
   if (key!=oldkey)
   {
      gotoxy(1,25);
      textcolor(LIGHTGRAY);
      sprintf(sl,"%-2s-%2d",notenames[key%12],key/12);
      outtext(sl);
      oldkey=key;
   }

   unsigned char huge *px = searchEvent(mx,my);

   gotoxy(7,25);
   if(px)
   {
      textcolor(pickChannel);
      sprintf(sl,"Channel:%2d",pickChannel);
      outtext(sl);
   } else outtext("          ");

   if (topnote<0)topnote=0;
   if (topnote>127-50)topnote=127-50;
   if (timeat<0)timeat=0;

   if (zoom<0)zoom=0;
   if (zoom>5)zoom=5;
   timeat -= timeat % (1<<zoom);
   if (topnote!=oldtopnote || timeat!=oldtime || zoom!=oldzoom)
      redraw();
   gotoxy(1,(miny+96)>>3);

   long ta=timeat+(mx<<zoom);

   textcolor(YELLOW);
   sprintf(sl,"Time:%6ld Top:%2s-%d Beat:%5d",ta,notenames[(127-topnote)%12],(127-topnote)/12,(int)(ta/ticksperquarter)+1);
   outtext(sl);
}

#pragma argsused
void MIDIView::processKey(int mx,int my,int key1,int key2)
{
   switch(key1)
   {
      case 0:
         switch(key2)
         {
            case 0x48:
               topnote--;
               break;

            case 0x50:
               topnote++;
               break;

            case 0x49: // pgup
               topnote=0;
               break;
            case 0x51: // pgdn
               topnote=127;
               break;

            case 0x84: // c-pgup
               timeat=0L;
               break;

            case 0x4d:
               timeat+=ticksperquarter;
               break;

            case 0x4b:
               timeat-=ticksperquarter;
               break;

            case 0x73: // c-left
               timeat-=ticksperquarter*4;
               break;
            case 0x74: // c-right
               timeat+=ticksperquarter*4;
               break;

            case 0x53: // gray del
               if (pickedEvent) deleteEvent();
               break;

            default:
               if (key2<=0x81 && key2 >= 0x78)
                  channelon[key2-0x78+1] ^= 1;
         }
         break;

      case '+':
         zoom--;
         break;

      case '-':
         zoom++;
         break;

      case 'l':
         long oldat = timeat;

         markleft=timeat + (mx<<zoom);
         timeat=markleft;
         if (timeat>postime)wind();
         else if (timeat<postime)
         {
            rewind();
            wind();
         }

         markpos = pos;
         marktime = postime;
         markrunstat = posrunstat;

         timeat=oldat;
         redraw();
         break;

      case 'r':
         markright=timeat + (mx<<zoom);
         redraw();
         break;
   }
}


void MIDIView::plotvert(int xp)
{
   unsigned char far *s;
   unsigned char bg;
   int y=miny;
   int x=minx+xp;
   int tn=topnote;
   void far *p=vertdata;
   long t;

   if (x<0||x>=SCRW)return;

   s = (unsigned char far *)MK_FP(0xa000,x+(y*SCRW));

   t = timeat+(x<<zoom);

   if (t<markright && t>=markleft) bg=15;
   else bg = 0;
/*   if (zoom<3)
   {
      if ((t%ticksperquarter)==0)bg=15;
      else if ((t%(ticksperquarter>>2))==0)bg=7;
      else bg=8;
   } else bg=8;
*/
   PUSH di
   PUSH si
   PUSH ds
   PUSH es

   LES di,s
   LDS si,p
   ADD si,tn

   MOV bl,byte ptr bg
   MOV bh,0fh

   MOV cx,40 // #notes to display (height)
vvv:
   LODSW
   AND al,bh
   JNZ fg1
   MOV al,bl
fg1:
   MOV es:[di],al
   AND ah,bh
   JNZ fg2
   MOV ah,bl
fg2:
   MOV es:[di+SCRW],ah

   ADD di,SCRW*2
   LOOP vvv

   POP es
   POP ds
   POP si
   POP di
}

void MIDIView::rewind(void)
{
   pos  = midiData;
   posrunstat = 0;
   postime = 0;
   posvoiceson=0;
   posx = 0;

   memset(vertdata,0,sizeof(vertdata));
   memset(leftvertdata,0,sizeof(vertdata));
}

void MIDIView::wind(void)
{
   int i;
   unsigned char cmd;
   unsigned char c;
   unsigned char d,data1,data2;
   unsigned char huge *op,huge *p;
   long ti;
   unsigned long value;
   int channel;

   memcpy(vertdata,leftvertdata,sizeof(vertdata));

   p  = pos;
   ti = postime;
   runstat = posrunstat;
   numvoiceson=posvoiceson;

   // spol frem til begyndelsespunkt

   for (;;)
   {
      op = p;
      if (op>=midiData+length) return;
      value=0L;
      for(;;) {
         c = *p++;
         value += c&0x7f;
         if (c&0x80) value <<= 7;
         else break;
      }



      ti += value;
      if (value) if (ti>=timeat) break;



      d = *p++;
      if (d==0xff) // meta-event
      {
         int t=*p++;
         int l=*p++;
         p += l;
         continue;
      }
      if (d<0x80)
      {
         cmd = runstat;
         data1 = d;
         data2 = *p++;
      } else
      {
         channel = (d&0x0f);
         cmd = d&0xf0;
         data1 = *p++;
         if (cmd<0xc0 || cmd>0xd0) data2 = *p++;
      }
      if (cmd==0x90 && data2>0) // note on
      {
         vertdata[127-data1] = channel+16;
      } else
      if ((cmd==0x90 && data2==0) || // note off w/o velocity
          (cmd==0x80))               // -    -   w.  -
      {
         if (vertdata[127-data1] == channel+16)
            vertdata[127-data1] = 0;
      }
      runstat = cmd;
   }

   pos = op;
   postime = ti-value;
   posrunstat = runstat;
   posx = (int)(timeat-postime);

   posvoiceson=0;
   for (i=0;i<128;i++)if (vertdata[i])posvoiceson++;
   memcpy(leftvertdata,vertdata,sizeof(vertdata));
}

unsigned char huge *MIDIView::searchEvent(int mx,int my)
{
   unsigned char cmd;
   unsigned char c;
   unsigned char d,data1,data2;
   unsigned char huge *op,huge *p;
   long evti; // time of event to search for
   int evkey; // vertdata index to search for
   long ti;
   unsigned long value;
   int channel,evchnl;

   pickedEvent=0;

   evti = postime+posx+(mx<<zoom);
   evkey = topnote+my;

   memcpy(vertdata,leftvertdata,sizeof(vertdata));

   p  = pos;
   ti = postime;
   runstat = posrunstat;

   for (;;)
   {
      op = p;
      if (op>=midiData+length) return 0;
      value=0L;
      for(;;) {
         c = *p++;
         value += c&0x7f;
         if (c&0x80) value <<= 7;
         else break;
      }



      if (vertdata[evkey])
      {
         unsigned char huge *pp;

         evchnl = vertdata[evkey]-16;

         if (ti<=evti && ti+value>evti)
         {
            // s�ledes kan begyndelsen af den fundne event findes:

            // 1) spol tilbage til begyndelsen af denne sk�rmfuld
            // 2) indtil xposition >= aktuel tid (evti)
            //       hvis noteon i samme channel+note, husk p
            //    hvis der findes flere, husk kun den sidste
            // 3) returner den huskede pointer p.

            // ulempe: virker kun p� events, der begynder p� eller
            // efter postime og alts� ikke p� events der begynder
            // udenfor venstre side af sk�rmen og r�kker ind over

            p  = pos;
            ti = postime;
            runstat = posrunstat;

            for (;;)
            {
               op = p;
               value=0L;
               for(;;) {
                  c = *p++;
                  value += c&0x7f;
                  if (c&0x80) value <<= 7;
                  else break;
               }
               d = *p++;
               if (d==0xff) // meta-event
               {
                  int t=*p++;
                  int l=*p++;
                  p += l;
                  continue;
               }

               if (d<0x80)
               {
                  cmd = runstat;
                  data1 = d;
                  data2 = *p++;
               } else
               {
                  channel = (d&0x0f);
                  cmd = d&0xf0;
                  data1 = *p++;
                  if (cmd<0xc0 || cmd>0xd0) data2 = *p++;
               }
               if (cmd==0x90 && data2>0) // note on
               {
                  if (127-data1==evkey && // det er den rigtige node
                     channel == evchnl)   // og kanal
                  {
                     pp = op; // husk op!
                     pickedEvent=pp;
                     pickRunStat = runstat;
                     pickTime = ti;//-value;
                     pickRunStat = cmd;
                     pickChannel = channel;
                  }
               }
               ti += value;
               if (value) if (ti>evti) break;
               runstat = cmd;
            }
            return pp;

         }
      }



      d = *p++;
      if (d<0x80)
      {
         cmd = runstat;
         data1 = d;
         data2 = *p++;
      } else
      {
         channel = (d&0x0f);
         cmd = d&0xf0;
         data1 = *p++;
         if (cmd<0xc0 || cmd>0xd0) data2 = *p++;
      }
      if (cmd==0x90 && data2>0) // note on
      {
         vertdata[127-data1] = channel+16;
      } else
      if ((cmd==0x90 && data2==0) || // note off w/o velocity
          (cmd==0x80))               // -    -   w.  -
      {
         if (vertdata[127-data1] == channel+16)
            vertdata[127-data1] = 0;
      }






      ti += value;
      if (value) if (ti>=timeat+(SCRW<<zoom)) break;
      runstat = cmd;
   }
   return 0; // no event found
}

void MIDIView::redraw(void)
{
   unsigned char c;
   unsigned char d,data1,data2;
   long value;
   int channel;
   unsigned char huge *p;
   long ti;

   oldtime=timeat; oldtopnote=topnote;oldzoom=zoom;

   mouse.hide();

   if (timeat>postime)wind();
   else if (timeat<postime)
   {
      rewind();
      wind();
   }
   p = pos;
   ti = postime;
   runstat = posrunstat;
   numvoiceson = posvoiceson;

   memcpy(vertdata,leftvertdata,sizeof(vertdata));

   for (;;)
   {
      value=0L;
      if (p>=midiData+length) break;
      for(;;) {
         c = *p++;
         value += c&0x7f;
         if (c&0x80)
            value <<= 7;
         else break;
      }
      if (value)
      {
        int xi;
        int xfrom,xto;

        xfrom = (int)(ti-timeat)>>zoom;
        xto   = (int)(ti-timeat+value)>>zoom;

        if (xfrom>319) break;
        if (xto>319||xto<0) xto=319;

        for (xi=xfrom;xi<xto;xi++)
           plotvert(xi);

        ti += value;
      }
      d = *p++;
      if (d==0xff)
      {
         int t=*p++;
         int l=*p++;
         p+=l;
         continue;
      }

      if (d<0x80)
      {
         data1 = d;
         data2 = *p++;
      } else
      {
         runstat = d&0xf0;
         channel = (d&0x0f);
         data1 = *p++;
         if (runstat<0xc0 || runstat>0xd0)
         {
            data2 = *p++;
         }
      }
      if (runstat==0x90 && data2>0) // note on
      {
         vertdata[127-data1] = channel+16;
         numvoiceson++;
      } else
      if ((runstat==0x90 && data2==0) || // note off w/o velocity
          (runstat==0x80))               // -    -   w.  -
      {
         if (vertdata[127-data1] == channel+16)
            vertdata[127-data1] = 0;
         numvoiceson--;
      }
   }
   horizline(0,miny+80,maxx,0);
   mouse.show();
}

void saveEdit(void)
{
   unsigned long c;
   unsigned char huge *p;
   FILE *f;
   char sl[100];

   char fn[MAXPATH],drive[MAXDRIVE],dir[MAXDIR],name[MAXFILE],ext[MAXEXT];
   fnsplit(xorName,drive,dir,name,ext);

   gotoxy(1,25);
   textcolor(WHITE);
   sprintf(sl,"Saving %s...",name);
   outtext(sl);
/*
   f=fileopen(xorName,"wb");
   if (f==0) return; // error: can't open file

   p = xorView->midiData;

   for (c=0L;c<xorView->length;c++)
   {
      putc(*p,f);
      p++;
   }
   fileclose(f);
*/
   fnmerge(fn,drive,dir,name,".PAT");
   savepatchdata(fn);
   fnmerge(fn,drive,dir,name,".INS");
   hw_saveinstruments(fn);
   gotoxy(1,25);

   outtext(emptyline);
   xorView->dirty=0;
}

int processKey(int key1,int key2)
// trap for all key controls at application level
// return 1 if key should not be sent to sub-control or 0 if it should
{
   switch(key1)
   {
      case 0:
         switch(key2)
         {
            case 60: // F2: save
               saveEdit();
               break;

            case 0x2d: // Alt-X
               if (xorView->dirty)
               {
                  gotoxy(1,25);
                  textcolor(WHITE);
                  outtext("File has changed. Save (Y/N) ?");
                  int c;
                  do
                  {
                     c= tolower(getch());
                     if (c==0)
                     {
                        c=getch();
                        continue;
                     }
                  } while (c!='y'&&c!='n'&&c!=27);
                  gotoxy(1,25);
                  textcolor(WHITE);
                  outtext(emptyline);
                  if (c=='y') saveEdit();
                  else if (c==27)break;
               }
               quit=1;
               return 1;
         }
         break;

         case ' ': // play
            editpatchsetup();
            break;
   }
   return 0;
}

void editloop(void)
{
   int key1,key2;
   unsigned mx,my,mb;
   unsigned long mp;

   mainView = new MIDIView(0,0,midiData,midiLength);
   xorView  = new MIDIView(0,96,xorData,xorLength);

   mainView->rewind(); // recalc pos & postime
   mainView->redraw();
   xorView->rewind();
   xorView->redraw();

   do {
      mp = mouse.pos();
      mx = (int)(mp&0xffff);
      my = (int)(mp>>16)&0x0fff;
      mb = (int)(mp>>30);

      thru();

      if (kbhit())
      {
         key1=getch();
         if (key1==0) key2=getch();

         if (processKey(key1,key2)==0)
         {
            if (mx <= mainView->maxx &&
                mx >= mainView->minx &&
                my <= mainView->maxy &&
                my >= mainView->miny
            ) mainView->processKey(mx-mainView->minx,my-mainView->miny,key1,key2);
            else if (mx <= xorView->maxx &&
                mx >= xorView->minx &&
                my <= xorView->maxy &&
                my >= xorView->miny
            ) xorView->processKey(mx-xorView->minx,my-xorView->miny,key1,key2);
         }
      }

      if (mx <= mainView->maxx &&
          mx >= mainView->minx &&
          my <= mainView->maxy &&
          my >= mainView->miny)
      {
        mainView->processMouse(mx-mainView->minx,my-mainView->miny,0);
        if (mainView->pickedEvent)
        {
           if (mb&1) // left mouse, copy event to xor-file
              mainView->copyNote(mainView->pickedEvent,xorView);
        }

      }
      else if (mx <= xorView->maxx &&
          mx >= xorView->minx &&
          my <= xorView->maxy &&
          my >= xorView->miny
      )
        xorView->processMouse(mx-xorView->minx,my-xorView->miny,0);




   } while (!quit);
}








void illfileerr(void)
{
   printf("Not a type 0 MIDI file\n");
   exit(1);
}

const unsigned long MThd = ((unsigned long)'M'<<24)+
                           ((unsigned long)'T'<<16)+
                           ('h'<<8)+
                            'd';

long getl(FILE *f) // l�ser et DWORD fra f i BIG ENDIAN format
{
   long v;

   v = (long)getc(f)<<24;
   v += (long)getc(f)<<16;
   v += (long)getc(f)<<8;
   v += getc(f);
   return v;
}

int main(int argc, char *argv[])
{
   FILE *f;
   unsigned long v;
   char fn[MAXPATH];

   mouse.init();

   if (argc!=2)
   {
      printf("Usage: smf0ed <filename[.MID]>\n<filename> must be a type 0 MIDI file.\n");
      exit(1);
   }

   strcpy(fn,argv[1]);
   if (!((fnsplit(fn,0,0,0,0)&EXTENSION))) strcat(fn,".MID");
   strupr(fn);

   if ((f=fopen(fn,"rb"))==0)
   {
      printf("%s not found.\n",fn);
      exit(1);
   }
   v=getl(f);
   if (v!=MThd) illfileerr();
   v=getl(f);
   if (v!=6) illfileerr();
   v=getword(f);
   if (v!=0) illfileerr();
   v=getword(f);
   if (v!=1) illfileerr();
   v=getword(f);
   if (v&0x8000)
   {
      printf("Kun SMF'er med 1/4-node-tick-underdeling kan bruges. Alts� ik' SMPTE'er.\n");
      exit(1);
   }
   ticksperquarter = (int)(v&0x7fff);

   // read MTrk header
   getl(f);

   // read length of track
   midiLength=getl(f);

   midiData = (unsigned char huge *)farmalloc(midiLength);
   xorData = (unsigned char huge *)farmalloc(midiLength);

   if ((!xorData)||(!midiData))
   {
      printf("Required memory : %ld bytes\nAvailable memory : %ld bytes.\n",
         midiLength*2,farcoreleft());
      exit(1);
   }

   {
      long n;
      int c;
      unsigned char huge *xp;

      xp = midiData;

      for(n=0L;n<midiLength;n++)
      {
         *xp++ = c = getc(f);
         if(c==-1)
         {
/*            printf("Error reading file.\n");
            exit(1);
*/
            midiLength = n;
            break;
         }
         if ((n%1000)==0) printf("Reading...%d%%\r",(int)((n*100)/midiLength));
      }
      printf("\n");
      fclose(f);
   }

   char drive[MAXDRIVE],dir[MAXDIR],name[MAXFILE],ext[MAXEXT];

   fnsplit(fn,drive,dir,name,ext);
   fnmerge(fn,drive,dir,name,".XOR");

   strcpy(xorName,fn);

   setmpuint();
   settimerint();
   emuinit();
	hw_loadinstruments("default.ins");
	loadpatchdata("default.pat");

   // attempt to load the real instruments, too

   fnmerge(fn,drive,dir,name,".INS");
   hw_loadinstruments(fn);
   fnmerge(fn,drive,dir,name,".PAT");
   loadpatchdata(fn);

   panic();

/*
   f = fileopen(fn,"rb");
   if (f)
   {
      unsigned long fl;
      long n;
      int c;
      unsigned char huge *xp;

      fl = filelength(fileno(f));
      xorLength = fl;
      xp = xorData;

      for(n=0L;n<fl;n++)
      {
         *xp++ = c = getc(f);
         if(c==-1)
         {
            printf("Error reading file.\n");
            exit(1);
         }
         if ((n%1000)==0) printf("Reading...%d%%\r",(int)((n*100)/fl));
      }
      fileclose(f);
      printf("\n");
   } else
*/
   {
      unsigned char huge *xp;

      // initialize a new xor-file

      xp = xorData;

      *xp++=0xff;
      *xp++=0xff;
      *xp++=0xff;
      *xp++=0x7f;
      xorLength=4;
   }

   grinit();
   mouse.show();
   editloop();
   panic();
   mouse.hide();
   restoretimerint();
   restorempuint();
   textinit();

   return 0;
}


