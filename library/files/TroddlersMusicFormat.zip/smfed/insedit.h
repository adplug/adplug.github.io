#include "adlib.h"

void buildtonelist(void);
void builddrumlist(void);
void allocatedrumlist(void);

int edittone(int);
int editpatch(int);
int editdrumset(void);
int savepatchdata(char *);
int loadpatchdata(char *);

#define PATCHNAMELEN 16
#define DRUMNAMELEN  28
extern char **patchnamedata;

#define NUMINSPARA	37	/* # ins. parameters in insedit window */