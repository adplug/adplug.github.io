#include <dos.h>
#include <conio.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>
#include <string.h>

#include "midi.h"
#include "globdat.h"
#include "inslist.h"
#include "midiemu.h"
#include "adlemuin.h"
#include "vga.h"

#include <asm.h>

void updateregspace(void);

volatile long tick;


static void interrupt (*oldint08)() = NULL;

void putdat(unsigned char v)
{
	emuputdat((unsigned char)v);
}

void panic(void) /* turn off ALL sound, reset controllers,
					initialize MPU-hardware */
{
	unsigned char	i;

	for (i=0;i<16;i++)
	{
		putdat(0xb0+i);
		putdat(0x78);	/* All sounds off */
		putdat(0x00);

		putdat(0xb0+i);
		putdat(0x7b);	/* All notes off */
		putdat(0x00);

		putdat(0xb0+i);
		putdat(0x79);	/* Reset all controllers */
		putdat(0x00);
	}
	IN	AL,61H
	AND	AL,0FCH
	OUT	61H,AL
}

unsigned tickLo=0;

void interrupt timerint(void)
{
   tick+=5;
   asm add tickLo,31457
   asm jnc nzz
   tick++;
nzz:
   updateregspace();

	hw_isr();
	MOV		AL,20H
	OUT		20H,AL
}

void settimerclock(unsigned clockrate)
{
	unsigned va;
	unsigned char lo,hi;

	va = 1193180.0 / clockrate;
	lo = va & 255;
	hi = va >> 8;

	MOV	AL,36H
	OUT	43H,AL

	asm {
		mov	al,lo
		out	40h,al
		nop
		mov al,hi
		out 40h,al
	}

	MOV	AL,0B6H
	OUT	43H,AL
}

void settimerint(void)
{
   if (oldint08==getvect(8)) return;
   tick=0L;
	oldint08 = getvect(8);
	setvect(8,timerint);

	settimerclock(70);

	IN	AL,21H
	AND	AL,0FEH
	OUT	21H,AL
}

void restoretimerint(void)
{
   if (oldint08==0) return;
	asm {
		mov	al,36h
		out	43h,al
		mov	al,0ffh
		out	40h,al
		nop
		out 40h,al
	}
	setvect(0x8,oldint08);
	oldint08 = NULL;
}
