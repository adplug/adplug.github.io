
struct patchcomp
{
	/*	a value of (UBYTE)-1 indicates that the tone is unused */

	unsigned char	ins1;		/* instrument (tone) number 1 */
	unsigned char	ins2;		/* instrument (tone) number 2 */
						/* ins1 has priority over ins2 */
						/* that is if there are not enough free voices */
						/* to play both tones, ins2 is left out first */
};

extern struct patchcomp _patchtable[];