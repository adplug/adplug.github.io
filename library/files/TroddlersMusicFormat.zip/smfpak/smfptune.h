struct smfptune
{
   char           id[4];              // "SMFP", no null-terminator
   unsigned char  outputformat;       // 0=adlib,1:sb
   unsigned       version;            // msb=major,lsb=minor
   char           copyright[32];      // (C), year, company, whodunnit
   unsigned char  drumins[128];       // drum key -> patch number
   unsigned char  drumnote[128];      // drum key -> key number
   unsigned char  drumpriority[128];  // drum key -> voice priority
   unsigned char  channelmaxvoice[16];// partial reserve
   unsigned char  channelpriority[16];// channel -> voice priority
   unsigned char  loop;               // loop tune after end flag (1==yes)
   unsigned char  numvoices;          // number of output voices to use
   unsigned char  pitchbenddefault;   // default semitone range of pitch bend
   unsigned char  patchtable[128][2]; // patch -> tone1 + tone2
   struct compactinstrument insdata[1];
};
