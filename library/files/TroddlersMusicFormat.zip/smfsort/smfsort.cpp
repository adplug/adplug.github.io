#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include <asm.h>
#include <dir.h>
#include <string.h>
#include <mem.h>
#include <alloc.h>
#include <io.h>
#include <asm.h>
#include <ctype.h>

long numchread=0L;

int getchr(FILE *f)
{
   numchread++;
   return getc(f);
}

#define getword(f) ((getchr(f)<<8)+getchr(f))


int numVarBytes(unsigned long value)
// return number of bytes required to store value in 7-bit variable length
// integer format
{
   if (value<=0x7fL) return 1;
   if (value<=0x3fffL) return 2;
   if (value<=0x1fffffL) return 3;
   if (value<=0xfffffffL) return 4;
   return 5;
}

void putVLValue(FILE *f,unsigned long value)
// put variable length integer value onto stream p and return the position
// of stream p after the insertion.
{
   int i;
   unsigned char c=0;
   unsigned char buffer[5];
   int nb = numVarBytes(value);

   for (i=nb-1;i>=0;i--)
   {
      *(buffer+i)=(unsigned char)(value&0x7f)|c;
      c=0x80;
      value >>= 7;
   }
   for (i=0;i<nb;i++) putc(buffer[i],f);
}

long getVLValue(FILE *f)
{
   unsigned char c;
   long value=0L;

   for (;;)
   {
      c=getchr(f);
      value += (c&0x7f);
      if (c&0x80) value<<=7;
      else break;
   }
   return value;
}

void illfileerr(void)
{
   printf("Not a type 0 MIDI file\n");
   exit(1);
}

const unsigned long MThd = ((unsigned long)'M'<<24)+
                           ((unsigned long)'T'<<16)+
                           ('h'<<8)+
                            'd';

long getl(FILE *f) // l�ser et DWORD fra f i BIG ENDIAN format
{
   long v;

   v = (long)getchr(f)<<24;
   v += (long)getchr(f)<<16;
   v += (long)getchr(f)<<8;
   v += getchr(f);
   return v;

}

unsigned char huge *midiData;
long midiLength;

struct midiEvent
{
   unsigned char data[3];
   int length;
} *ev;


int scmp(const void *a, const void *b)
{
   midiEvent *a1,*b1;

   a1 = (midiEvent *)a;
   b1 = (midiEvent *)b;

   if (a1->length == 3 &&
       b1->length == 3)
   {
      if ( a1->data[0] == 0x80 ||                    // noteoff w. velocity
          (a1->data[0] == 0x90 && a1->data[2] == 0)) // normal note off
      {
         if (b1->data[0] == 0x90 && b1->data[2] != 0) // note on
            return 1; // note off first
      } else
      if ( b1->data[0] == 0x80 ||                    // noteoff w. velocity
          (b1->data[0] == 0x90 && b1->data[2] == 0)) // normal note off
      {
         if (a1->data[0] == 0x90 && a1->data[2] != 0) // note on
            return -1; // note off first
      }
   }
   return 0; // don't care
}


int main(int argc, char *argv[])
{
   FILE *f;
   FILE *outf;
   unsigned long v;

   // max. 200 events at the same time - should suffice i think.
   ev = (struct midiEvent*)farmalloc(sizeof(struct midiEvent)*200L);

   if (argc!=3)
   {
      printf("Usage: smfsort <infile> <outfile>\nSorts a type 0 SMF, note-offs first then note-ons.\n");
      exit(1);
   }

   if ((f=fopen(argv[1],"rb"))==0)
   {
      printf("%s not found.\n",argv[1]);
      exit(1);
   }
   outf = fopen(argv[2],"wb");

   v=getl(f);
   if (v!=MThd) illfileerr();
   v=getl(f);
   if (v!=6) illfileerr();
   v=getword(f);
   if (v!=0) illfileerr();
   v=getword(f);
   if (v!=1) illfileerr();
   v=getword(f);
   if (v&0x8000)
   {
      printf("Kun SMF'er med 1/4-node-tick-underdeling kan bruges. Alts� ik' SMPTE'er.\n");
      exit(1);
   }
//   ticksperquarter = (int)(v&0x7fff);

   // read MTrk header
   getl(f);

   // read length of track
   midiLength=getl(f);

   {
      long p = ftell(f);
      void *d;
      rewind(f);

      d=farmalloc(p);
      fread(d,(int)p,1,f);
      fwrite(d,(int)p,1,outf);
      fseek(f,p,SEEK_SET);
      farfree(d);
   }
   {
      int nume;
      int c;
      unsigned char runStat=0,wrStat=0xff;
      int i;

      while(numchread<midiLength)
      {
         long ptime=0L;
         nume=0;

         do
         {
            ptime=getVLValue(f);
            c = getchr(f);
            if (c<0x80)
            {
               ev[nume].data[0] = runStat;
               ev[nume].data[1] = c;
            } else
            {
               ev[nume].data[0] = c;
               ev[nume].data[1] = getchr(f);
            }
            if (ev[nume].data[0]!=0xc0 &&
                ev[nume].data[0]!=0xe0) // 3 byte event
            {
               ev[nume].data[2] = getchr(f);
               ev[nume].length = 3;
            } else ev[nume].length = 2;
            runStat = ev[nume].data[0];
            nume++;
         } while (ptime==0L);

         if (nume>1) // sort events before writing
         {
            qsort(ev,nume,sizeof(struct midiEvent),scmp);
         }
         for (i=0;i<nume-1;i++)
         {
            putVLValue(outf,0L);
            if (wrStat!=ev[i].data[0]) putc(ev[i].data[0],outf);
            putc(ev[i].data[1],outf);
            if (ev[i].length==3)
               putc(ev[i].data[2],outf);
            wrStat = ev[i].data[0];
         }
         putVLValue(outf,ptime);
         if (wrStat!=ev[i].data[0]) putc(ev[i].data[0],outf);
         putc(ev[i].data[1],outf);
         if (ev[i].length==3)
            putc(ev[i].data[2],outf);
         wrStat = ev[i].data[0];
      }
      printf("\n");
      fclose(f);
   }

   return 0;
}


