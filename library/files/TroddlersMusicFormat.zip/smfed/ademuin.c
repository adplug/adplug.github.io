#include <conio.h>

#include "adlemuint.h"
#include "adlib.h"

/*	denne rutine kaldes v. 70Hz. */

void hw_isr(void)
{
	unsigned char	vc,
			reg,
			dat;

	unsigned	d;

	int		modv,
			modd,
			detunev,
			tvpv;

	struct tinstrument *tp;

	for(vc=0;vc<9;vc++)
	{
		/*	calculate modulator controlled lfo */

		tp = &_insdata[hwvins[vc]];

		if (tp->mod_lfo_rate)
		{
			modv = fqdata[hwvkey[vc]+4]-fqdata[hwvkey[vc]];
			if (modv > 680) modv -= 680;

			modv = (modv * tp->mod_lfo_depth) >> 4;

			modd = hwvmodlfocnt[vc];
			if (modd >= tp->mod_lfo_rate)
				modd = (tp->mod_lfo_rate*2) - modd;
			modd -= (tp->mod_lfo_rate/2);

			modv = (modv * modd) / tp->mod_lfo_rate;

			if (++hwvmodlfocnt[vc] == tp->mod_lfo_rate*2)
				hwvmodlfocnt[vc]=0;

			modv = (modv * _modvalue[vc])/128;
		} else modv = 0;

		/*	calculate detune */

		if (tp->detune)
		{
			detunev = fqdata[hwvkey[vc]+1]-fqdata[hwvkey[vc]];
			if (detunev > 680) detunev -= 680;

			detunev = (detunev * tp->detune) >> 5;
		} else detunev = 0;



		if (tp->tvp_depth != 32) /* 32 = zero depth */
        {
            if (hwvtime[vc] >= tp->tvp_rate) tvpv = 0;
            else
            {
                tvpv = 0x400-680;	 	/* == 1 octaves */

            	tvpv = (tvpv * (((int)tp->tvp_depth)-32)) / 32;
                tvpv = (tvpv * ((int)tp->tvp_rate-(int)hwvtime[vc])) / (int)tp->tvp_rate;
            }
        } else tvpv = 0;




		/*	output frequency and state of KON to hw */

		d = hwvfq[vc];

        d += tvpv;							/* add pitch change */
		if ((d & 0x3ff) > 688) d += 680;
		else if ((d & 0x3ff) < 344) d -= 680;

		d += modv;							/* add modulator control */
		if ((d & 0x3ff) > 688) d += 680;
		else if ((d & 0x3ff) < 344) d -= 680;

		d += detunev;						/* add detune */
		if ((d & 0x3ff) > 688) d += 680;
		else if ((d & 0x3ff) < 344) d -= 680;

		reg = 0xa0+vc;
		dat = d & 0xff;
		OUTADL

		reg += 0x10;

		dat = noteoninfo[vc] | (d >> 8);
		OUTADL

		hwvtime[vc]++;
	}
}
