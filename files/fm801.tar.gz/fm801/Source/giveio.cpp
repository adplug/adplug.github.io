/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#pragma hdrstop
#include "giveio.h"
#pragma package(smart_init)
void giveio(void)
{
        HANDLE h= CreateFile("\\\\.\\giveio", GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if(h==INVALID_HANDLE_VALUE)
                throw ("Couldn't access giveio device");
        CloseHandle(h);
}
void outp(ULONG port, BYTE value)
{
        asm
        {
                mov edx, port
                mov al, value
                out dx, al
        }
}
void outpw(ULONG port, USHORT value)
{
        asm
        {
                mov edx, port
                mov ax, value
                out dx, ax
        }
}
void outpd(ULONG port, ULONG value)
{
        asm
        {
                mov edx, port
                mov eax, value
                out dx, eax
        }
}
BYTE inp(ULONG port)
{
        BYTE value;
        asm
        {
                mov edx, port
                in al, dx
                mov value, al
        }
        return value;
}
USHORT inpw(ULONG port)
{
        USHORT value;
        asm
        {
                mov edx, port
                in ax, dx
                mov value, ax
        }
        return value;
}
ULONG inpd(ULONG port)
{
        ULONG value;
        asm
        {
                mov edx, port
                in eax, dx
                mov value, eax
        }
        return value;
}

