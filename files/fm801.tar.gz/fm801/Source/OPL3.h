/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#ifndef opl3H
#define opl3H
#include <Classes.hpp>
#define OPL3BANK0 (0x0000)
#define OPL3DATA0 (0x0001)
#define OPL3BANK1 (0x0002)
#define OPL3DATA1 (0x0003)

class OPL3
{
        private:
                USHORT OPLBase;
        protected:
                void writeb(USHORT, BYTE);
        public:
                OPL3(USHORT);
                ~OPL3(void);

                void opl2on(void);
                void opl3on(void);
};
#endif
