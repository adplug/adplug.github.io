
#define SONG_FNEXTENSION  ".sng"
#define INS_FNEXTENSION   ".ins"
#define PATCH_FNEXTENSION ".pat"

#define DEFAULTS_FILE	  "seq.def"

#define DEFAULT_SNG_DIRECTORY "sng\\"
#define DEFAULT_INS_DIRECTORY "ins\\"
#define DEFAULT_PAT_DIRECTORY "pat\\"

void savesong(struct songnode *,char *);
int	loadsong(char *,struct songnode *);
void savemusicdata(char *, struct songnode *);
void loadmusicdata(char *, struct songnode *);
int loaddefaults(void);
