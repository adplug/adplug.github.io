

#ifndef ADLIB_H
#define ADLIB_H

#define	NUMINSTRUMENTS	256			/* 	number of basic instruments to
										load from instrument data file */

struct tinstrument
{
	unsigned char	key_scale_level[2];
	unsigned char	frequency_multiplier[2];
	unsigned char	feed_back[2];
	unsigned char	attack_rate[2];
	unsigned char	sustain_level[2];
	unsigned char	sustaining_sound[2];
	unsigned char	decay_rate[2];
	unsigned char	release_rate[2];
	unsigned char	output_level[2];
	unsigned char   amplitude_vibrato[2];
	unsigned char	frequency_vibrato[2];
	unsigned char	envelope_scaling[2];

	unsigned char	combine_method;
	unsigned char	wave_form_for_modulator;
	unsigned char	wave_form_for_carrier;

	unsigned char	mod_lfo_depth;			/* 	modulator control lfo depth */
	unsigned char	mod_lfo_rate;			/*	modulator control lfo rate  */

	unsigned char	detune;

	unsigned char	keyoff_decay_rate[2];
	unsigned char	keyoff_sustain_level[2];

    unsigned char	velo_sens[2];

    unsigned char	tvp_depth;				/* time variable pitch depth */
    unsigned char	tvp_rate;				/* time variable pitch rate */

    unsigned char coarse_detune;

	unsigned char	pad[4];				/*	reserved for future use */
};

struct compactinstrument
{
   unsigned char reg20[2];
   unsigned char reg40[2];
   unsigned char reg60[2];
   unsigned char reg80[2];
   unsigned char regc0;
   unsigned char wave_form_for_modulator;
   unsigned char wave_form_for_carrier;
   unsigned char velo_sens[2];
	unsigned char keyoff_reg60[2];
	unsigned char keyoff_reg80[2];

   unsigned char mod_lfo_depth;
	unsigned char mod_lfo_rate;

	unsigned char detune;
   unsigned char coarse_detune;

   unsigned char tvp_depth;
   unsigned char tvp_rate;

   unsigned char output_level[2];

};

#endif
