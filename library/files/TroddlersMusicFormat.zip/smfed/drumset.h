extern unsigned char drumins[128];		   /* drum set key instrument assignment */
extern unsigned char drumnote[128];		/* drum set note assignment */
extern unsigned char drumpriority[128];  /* drum priority table */
