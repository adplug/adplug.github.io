/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#ifndef giveioH
#define giveioH
#include <Classes.hpp>
void giveio(void);
void outp(ULONG port, BYTE value);
void outpw(ULONG port, USHORT value);
void outpd(ULONG port, ULONG value);
BYTE inp(ULONG port);
USHORT inpw(ULONG port);
ULONG inpd(ULONG port);
#endif
