#pragma hdrstop
#include "CCSRegistry.h"
#pragma package(smart_init)

CCSRegistry::CCSRegistry(void)
{
        PortAddress=0;  /* n/a */
        Registry= new TRegistry(KEY_READ);
        AnsiString PCI= "SYSTEM\\CurrentControlSet\\Enum\\PCI";

        Devices= new TStringList;
        Registry->RootKey= HKEY_LOCAL_MACHINE;
        Registry->OpenKey(PCI, false);
        Registry->GetKeyNames(Devices);
        Registry->CloseKey();

        DeviceEntries= new TStringList;
        for(int i=0; i<Devices->Count; i++)
        {
                AnsiString vendor_device= (Devices->Strings[i]).SubString(0, 17);
                if( vendor_device != (AnsiString) FM801_VEN_DEV)
                        continue;

                Registry->OpenKey(PCI + "\\" + Devices->Strings[i], false);
                Registry->GetKeyNames(DeviceEntries);
                Registry->CloseKey();

                DeviceEntry= new TStringList;
                for(int j=0; j<DeviceEntries->Count; j++)
                {
                        if( Registry->OpenKey(PCI + "\\" + Devices->Strings[i] + "\\" + DeviceEntries->Strings[j] + "\\Control", false)== false )
                                continue;
                        bool AllocConfig= Registry->ValueExists("AllocConfig");
                        Registry->CloseKey();
                        if(!AllocConfig)
                                continue;

                        if( Registry->OpenKey(PCI + "\\" + Devices->Strings[i] + "\\" + DeviceEntries->Strings[j] + "\\LogConf", false)== false )
                                continue;
                        if(Registry->ValueExists("BootConfig"))
                        {
                                UCHAR *buffer= new UCHAR[1024];
                                Registry->ReadBinaryData("BootConfig", (void *)buffer, 1024);
                                PCM_RESOURCE_LIST resList= (PCM_RESOURCE_LIST)buffer;
                                PCM_FULL_RESOURCE_DESCRIPTOR resDesc= &resList->List[0];
                                if(resDesc->InterfaceType==PCIBus)
                                {
                                        PCM_PARTIAL_RESOURCE_LIST presList= &resDesc->PartialResourceList;
                                        for(UINT k=0; k<presList->Count; k++)
                                        {
                                                PCM_PARTIAL_RESOURCE_DESCRIPTOR presDesc= &presList->PartialDescriptors[k];
                                                if(presDesc->Type==CmResourceTypePort)
                                                        PortAddress= (USHORT) presDesc->Start;
                                        }
                                }
                                delete buffer;
                        }
                        Registry->CloseKey();
                }
                delete DeviceEntry;
        }
        delete DeviceEntries;
        delete Devices;
        delete Registry;
}

CCSRegistry::~CCSRegistry(void)
{
}

USHORT CCSRegistry::GetPortAddress(void)
{
        return PortAddress;
}
