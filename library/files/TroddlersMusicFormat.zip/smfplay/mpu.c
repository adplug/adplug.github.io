#include <conio.h>
#include <dos.h>
#include <clibex.h>

#define INPBUFSIZE 50 // size of midi input buffer

int		dataport = 0x330;
int		cmdport  = 0x331;

int _echochannel=0;

unsigned char inpbuf[INPBUFSIZE];
int	 bufr=0,bufw=0;

static void interrupt (*oldint0a)();

void flushinpbuf(void)
{
	bufr = bufw = 0;
}

void callsmfp(unsigned cmd);

void emuputdat(unsigned char v)
{
   _AL = v;
   callsmfp(2);
}

void putcom(unsigned char v)
{
		MOV		dx,cmdport
		XOR		cx,cx
portisntready:
		IN		   al,dx
		AND		al,40h
		JZ		   portisready
		LOOP	   portisntready
      JMP      skipwrite
portisready:
		MOV		al,v
		OUT		dx,al
skipwrite:
}

int getdat(void)
// returns byte read from MPU or -1 on error.
{
		MOV		dx,cmdport
		XOR		cx,cx
portisntready:
		IN		al,dx
		AND		al,40h
		JZ		portisready
		LOOP	portisntready
      return -1;
portisready:
		DEC		dx
		IN		al,dx
skipread:
	return _AL;
}

unsigned char readbufdat(void)
{
	unsigned char c;

	while (bufr == bufw);
	c = inpbuf[bufr];
	if (++bufr >= INPBUFSIZE) bufr=0;
	return c;
}

void thru(void)
{
	unsigned char a,cmd;
   static unsigned char runstat;

	while (bufr != bufw)
	{
		a = readbufdat();
	   if (a != 0xfe) // active sensing filter
      {
         if (a<0x80)
         {
            emuputdat(runstat);
            emuputdat(a);
            cmd=runstat;
         } else
         {
            unsigned char b;
            emuputdat(a);
            b=readbufdat();
            emuputdat(b);
            cmd=a;
         }
         runstat=cmd;
         cmd&=0xf0;
         if (cmd!=0xc0&&cmd!=0xd0)
         {
            unsigned char c;

            c=readbufdat();
            emuputdat(c);
         }
      }
	}
}


void interrupt mpuint(void)
{
	unsigned char	a;

	MOV		DX,331H
waitPort:
	IN		   AL,DX
	AND		AL,80H
	JNZ		waitPort

	a=getdat();
   inpbuf[bufw] = a;
   if (++bufw >= INPBUFSIZE) bufw = 0;

	MOV		AL,20H
	OUT		20H,AL

}

void setmpuint(void)
{
	oldint0a = getvect(0xa);
	setvect(0xa,mpuint);

	IN		   AL,21H
	AND		AL,0FBH
	OUT		21H,AL

 	putcom(0xff);
   putcom(0x3f);
  	getdat();
}

void restorempuint(void)
{
	IN		   AL,21H
	OR		   AL,4
	OUT		21H,AL

	setvect(0xa,oldint0a);
	putcom(0xff);
}

