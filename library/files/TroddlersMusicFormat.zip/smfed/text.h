#ifdef __cplusplus
extern "C" {
#endif
void gotoxy(int,int);
void textcolor(int);
void outtext(const char *);
#ifdef __cplusplus
}
#endif
