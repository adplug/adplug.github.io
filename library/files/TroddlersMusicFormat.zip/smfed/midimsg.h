/*	---------------------- DEFINES FOR MIDI DATA ------------------ */

/*	MIDI command headers */

#define CMD_NOTEOFF		  	0x80		/* note off with velocity */
#define CMD_NOTE		  	0x90 		/* note data */
#define CMD_POLY_KEY_PRES	0xa0		/* polyphonic key pressure */
#define CMD_CC				0xb0		/* control change/channel mode msg */
#define CMD_PROGRAM_CHANGE	0xc0		/* program change */
#define CMD_CHANNEL_PRES	0xd0		/* channel pressure */
#define CMD_PITCH_BEND		0xe0		/* pitch bend */
#define CMD_ACTIVE_SENSING	0xfd		/* active sensing */
#define CMD_EXCLUSIVE		0xf0		/* system exclusive */
#define CMD_EXCLUSIVE_END	0xf7		/* EOX - end of exclusive */

/*	Control change messages, used after receiving a CMD_CC */

#define	CC_BANK_SELECT		0x00		/* bank select control */
#define CC_BANK_SELECT2		0x20		/* bank select (dummy bank of 0) */
#define CC_MODULATION		0x01		/* modulation */
#define CC_PORTAMENTO_TIME	0x05		/* portamento time */
#define CC_DATA_ENTRY_MSB	0x06		/* data entry of RPN/NRPN (msb) */
#define CC_DATA_ENTRY_LSB	0x26		/* data entry of RPN (lsb) */
#define CC_VOLUME			0x07		/* volume change */
#define CC_PANPOT			0x0a		/* panpot */
#define CC_EXPRESSION		0x0b		/* expression */
#define CC_HOLD1			0x40		/* hold pedal */
#define CC_PORTAMENTO		0x41		/* portamento on/off */
#define CC_SOSTENUTO		0x42		/* sostenuto */
#define CC_SOFT				0x43		/* soft */
#define CC_LGC				0x54		/* legato control */
#define CC_EFFECT1_DEPTH	0x5b		/* reverb send depth */
#define CC_EFFECT3_DEPTH	0x5d		/* chorus send depth */
#define CC_NRPM_MSB			0x63		/* non-registered parameter msb */
#define CC_NRPM_LSB			0x62		/* non-registered parameter lsb */
#define CC_RPN_MSB			0x65		/* registered parameter msb */
#define CC_RPN_LSB			0x64		/* registered parameter lsb */

/*	Channel mode messages, used after receiving a CMD_CC (not an error!) */

#define	CM_ALL_SOUNDS_OFF	0x78		/* all sounds off */
#define CM_RESET_ALL_CTRLS	0x79		/* reset all controllers */
#define	CM_ALL_NOTES_OFF	0x7b		/* all notes off */
#define	CM_OMNI_OFF			0x7c		/* omni off */
#define	CM_OMNI_ON			0x7d		/* omni on */
#define	CM_MONO				0x7e		/* mono */
#define	CM_POLY				0x7f		/* poly */

/*	----------------- MIDI flow control ----------------- */

/*  Values for expected, based on command values */

#define EXP_ANYTHING	  	0			/* don't know */
#define	EXP_NOTE			1			/* note number (noteon/off etc) */
#define	EXP_VELOCITY		2			/* velocity (noteon/off etc) */
#define	EXP_POLY_PRES		3			/* poly pressure value */
#define	EXP_CC_MSG			4			/* control change/channel mode msg */
#define	EXP_CC_VALUE		5			/* control change/channel mode val */
#define	EXP_PROGRAM			6			/* program change value */
#define	EXP_CHANNEL_PRES	7			/* channel pressure value */
#define	EXP_PITCH_BEND_LSB	8			/* pitch bend value, lsb */
#define EXP_PITCH_BEND_MSB	9			/* pitch bend value, msb */
#define EXP_EXCLUSIVE_END	10			/* end of system exclusive */
#define EXP_NOTEOFF_NOTE 11
#define EXP_NOTEOFF_VELOCITY 12     /* note off velocity */
