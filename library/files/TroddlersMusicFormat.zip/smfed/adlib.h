
#ifndef ADLIB_H
#define ADLIB_H

#define	NUMINSTRUMENTS	256			/* 	number of basic instruments to
										load from instrument data file */

struct tinstrument
{
	unsigned char	key_scale_level[2];
	unsigned char	frequency_multiplier[2];
	unsigned char	feed_back[2];
	unsigned char	attack_rate[2];
	unsigned char	sustain_level[2];
	unsigned char	sustaining_sound[2];
	unsigned char	decay_rate[2];
	unsigned char	release_rate[2];
	unsigned char	output_level[2];
	unsigned char   amplitude_vibrato[2];
	unsigned char	frequency_vibrato[2];
	unsigned char	envelope_scaling[2];

	unsigned char	combine_method;
	unsigned char	wave_form_for_modulator;
	unsigned char	wave_form_for_carrier;

	unsigned char	mod_lfo_depth;			/* 	modulator control lfo depth */
	unsigned char	mod_lfo_rate;			/*	modulator control lfo rate  */

	unsigned char	detune;

	unsigned char	keyoff_decay_rate[2];
	unsigned char	keyoff_sustain_level[2];

    unsigned char	velo_sens[2];

    unsigned char	tvp_depth;				/* time variable pitch depth */
    unsigned char	tvp_rate;				/* time variable pitch rate */

   unsigned char  coarse_detune;
	unsigned char	pad[4];				/*	reserved for future use */
};

#define MODULATOR	0
#define	CARRIER 	1

#define	FM			1
#define	ADDITIVE	0

/*	interface to midiemu.c */

extern  unsigned char _pbsens;		/* pitch bend sensitivity */
extern  int  _pbvalue[];	/* pitch bend value */
extern	unsigned char _modvalue[];	/* modulator value */

/*	interface to adlemuin.c	*/

extern	struct tinstrument *_insdata; /* instrument list */
extern	unsigned char	noteoninfo[];
extern	unsigned char	velotab[];

extern unsigned fqdata[128];		/* frequency data for each note */
								/* initialized in hw_init() */

extern unsigned char hwvkey[9];			/* key number for hw voice */

extern unsigned char drumins[128];		/* drum set key to instrument assignment */
extern unsigned char drumnote[128];		/* drum set note assignment */
extern unsigned hwvtime[9];	    /* time since last noteon */
extern unsigned char hwvmodlfocnt[9];	/* modulator lfo count */
extern unsigned hwvfq[9];			/* base frequency of note including pitch
								   bend but not modulation */
extern unsigned char hwvins[9];			/* active instrument */

#ifdef __cplusplus
extern "C" {
#endif
int	hw_emuinit(void);
int	hw_loadinstruments(char *filename);
int	hw_saveinstruments(char *filename);
void	hw_pbchange(unsigned char);
void	hw_drumon(unsigned char, unsigned char, unsigned char);
void	hw_noteon(unsigned char, unsigned char, unsigned char, unsigned char);
void	hw_noteoff(unsigned char);

void	outadl(void);		/* to be found in adlhw.asm.
								takes register in al and data in ah */
#ifdef __cplusplus
}
#endif

#define OUTADL asm {\
mov al,reg;\
mov ah,dat;\
}\
outadl();



#endif
