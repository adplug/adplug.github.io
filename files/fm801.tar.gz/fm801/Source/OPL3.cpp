/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#pragma hdrstop
#include "OPL3.h"
#include "giveio.h"
#pragma package(smart_init)

OPL3::OPL3(USHORT address)
{
        OPLBase= address;
        opl3on();
}

OPL3::~OPL3(void)
{
}

void OPL3::writeb(USHORT reg, BYTE data)
{
        if(reg<256)
        {
                outp(OPLBase + OPL3BANK0, (BYTE)reg);
                outp(OPLBase + OPL3DATA0, data);
        }
        else if(reg<512)
        {
                outp(OPLBase + OPL3BANK1, (BYTE)(reg & 255));
                outp(OPLBase + OPL3DATA1, data);
        }
        else
                throw "Illegal OPL3 register index";
}

void OPL3::opl2on(void)
{
        writeb(0x105, 0);
        writeb(0x104, 0);
}

void OPL3::opl3on(void)
{
        writeb(0x105, 1);
        writeb(0x104, 0);
}