
#define PATCHNAMELEN 		16
#define PATCHLISTMAXINSTR 	256

struct patch
{
	char name[PATCHNAMELEN];
	int	bs;/* bank select    */
	int pc;/* program change */
};

extern struct patch		 	*patchlist;
extern char 				**patchliststr;
extern struct patch		 	*drumlist;
extern char 				**drumliststr;

int  selectpatch(int isdrumset, int);
void loadpatchlist(void);
