#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <dos.h>
#include <alloc.h>
#include <dir.h>
#include <string.h>
#include <io.h>
#include <ctype.h>
#include "\src\smf\smfpak\adlib.h"
#include "\src\smf\smfpak\smfptune.h"

// if ENABLESFX is defined, the demo program will include code to load and
// play sound fx.
// #define ENABLESFX

// if ENABLEMUSIC is defined, the demo program will include code to load
// and play music.
#define ENABLEMUSIC


#define SMFP_INITIALIZE   0
#define SMFP_LOADTUNE     1
#define SMFP_PUTMIDIDATA  2
#define SMFP_ISR          3
#define SMF_LOADTUNE      4
#define SMF_ISR           5
#define SMF_STOPTUNE      6
#define SFX_LOADSFX       7    /* load segment of sfx */
#define SFX_PLAYSOUND     8    /* play sound */
#define SFX_STOPSFX       9    /* stop all sfx */
#define SFX_PLAYSFX      10    /* play sfx */

unsigned char huge *smf;   /* standard MIDI file */
struct smfptune far *mfp;   /* MIDI file patch    */

void setmpuint(void);
void restorempuint(void);
void thru(void);

#ifdef ENABLESFX
void getsfxseg(void);
#endif

void far midiemu_entry_point(void);

void vgasetcolor(unsigned char reg, unsigned char value)
{
    asm {
    	mov		dx,3dah
	}
hr1:
    asm {
        in		al,dx

        and		al,1
        jnz		hr1
	}
hr2:
    asm {
        in		al,dx

        and		al,1
        jz		hr2

        mov		dx,3c0h

        mov		al,reg
		out		dx,al
        mov		al,value
        out		dx,al
        mov		al,20h
        out		dx,al
    }
}

void callsmfp(int cmd)
{
   asm push ax
   vgasetcolor(0,63);
   asm mov bx,cmd
   asm pop ax
   midiemu_entry_point();
   vgasetcolor(0,0);
}

void *loadfile(char *fn,char *ext)
{
   FILE *f;
   char name[MAXPATH];
   unsigned long l;
   unsigned char far *dest;

   strcpy(name,fn);
   strcat(name,ext);
   strupr(name);
   f=fopen(name,"rb");
   if (f==0)
   {
      printf("%s not found.\n",name);
      exit(1);
   }
   l=filelength(fileno(f));
   dest=farmalloc(l+16);
   if (dest==0)
   {
      printf("Not enough memory.\n");
      exit(1);
   }
   dest = MK_FP(FP_SEG(dest)+1,0);
   {
      int c;
      unsigned char *d;
      d=dest;

      while((c=getc(f))!=EOF)
      {
         *d++ = c;
      }
   }
   fclose(f);
   return dest;
}

#pragma argsused
main(int argc,char *argv[])
{
   int quit=0;
   int speed=1;


   callsmfp(SMFP_INITIALIZE);

#ifdef ENABLEMUSIC
   if(argc!=2)
   {
      printf("Usage: smfptest <filename>\nRequires <filename>.MID and <filename>.MFP\n");
      exit(0);
   }
   smf=loadfile(argv[1],".MID");
   mfp=loadfile(argv[1],".MFP");


   _AX = FP_SEG(mfp);
   callsmfp(SMFP_LOADTUNE);
#endif

#ifdef ENABLESFX
   getsfxseg();
   callsmfp(SFX_LOADSFX);
#endif

#ifdef ENABLEMUSIC
   _AX = FP_SEG(smf);
   callsmfp(SMF_LOADTUNE);
#endif

#ifdef ENABLEMUSIC
   printf("1-1 for music. F1 to restart.\n");
#endif
#ifdef ENABLESFX
   printf("A-Z, 0-4 for SFX\n");
#endif
   printf("Press ESC to quit.\n");
   do
   {
      int n,c;

      while((unsigned char)inportb(0x3da)&(unsigned char)8);
      while(!(inportb(0x3da)&8));
      delay(2);
      for(n=0;n<speed;n++)
         callsmfp(SMF_ISR);
      if (kbhit())
         switch(c=tolower(getch()))
      {
         case '+':speed++;break;
         case '-':speed--;break;

         case 27:
            quit=1;
            break;

#ifdef ENABLEMUSIC
         case '1':
         case 13:
#ifdef ENABLESFX
            callsmfp(SFX_STOPSFX);
#endif
            _AX = FP_SEG(smf);
            callsmfp(SMF_LOADTUNE);
            break;

         case ' ':
            callsmfp(SMF_STOPTUNE);
            break;
#endif

#ifdef ENABLESFX
         default:
            if (c>='a' && c<='z')
            {
               _AX = c-'a';
               callsmfp(SFX_PLAYSFX);
               break;
            } else
            if (c>='0' && c<='2')
            {
               _AX = c-'0'+'z'-'a'+1;
               callsmfp(SFX_PLAYSFX);
               break;
            }
#endif
      }
   } while (!quit);
#ifdef ENABLESFX
   callsmfp(SFX_STOPSFX);
#endif
   callsmfp(SMFP_INITIALIZE);
   return 0;
}
