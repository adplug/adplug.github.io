#include <asm.h>
#include <dos.h>
#include "mouse.h"

void Mouse::init(void)
{
   XOR ax,ax
   INT 33h
}

void Mouse::show(void)
{
   MOV ax,1
   INT 33h
}

void Mouse::hide(void)
{
   MOV ax,2
   INT 33h
}

unsigned long Mouse::pos(void) // returns X in AX and y in DX
{
   MOV ax,3
   INT 33h
   XOR ax,ax
   SHR bx,1
   RCR ax,1
   SHR bx,1
   RCR ax,1
   OR  dx,ax
   MOV ax,cx
   SHR ax,1 // div med 2 for at f� 320x200
   return (unsigned long)(MK_FP(_DX,_AX));
}
