#include "midi.h"
#include "globdat.h"
#include <stdlib.h>
#include <stdio.h>

