class Mouse
{
public:
   void init();
   void show();
   void hide();
   unsigned long pos();
};
