#include <stdio.h>
#include <stdlib.h>
#include "midi.h"
#include "file.h"

static unsigned _filecount = 0;

FILE *fileopen(char *name, char *mode)
{
    FILE *f;
    if (_filecount==0) restoretimerint();
    f = fopen(name, mode);
    if (f == NULL)
    {
       if (_filecount==0) settimerint();
       return 0;
    }
    _filecount++;
    return f;
}

void fileclose(FILE *file)
{
	fclose(file);
	_filecount--;
    if (_filecount == 0) settimerint();
}
