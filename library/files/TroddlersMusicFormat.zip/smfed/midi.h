#ifndef MIDI_H
#define MIDI_H

void memerr(void);

#include "node.h"

#define INPBUFSIZE 		1024	/* MIDI Input buffer size */

#define BEATMETROFREQ   500
#define MEASMETROFREQ	1000

#define MAXTRACKEVENTS  500		/* max. #events per track */
#define MAXTRACKSEQ		100		/* max. #tracks per sequence */

#define TRACKNAMELEN    32		/* length of track name */
#define SEQNAMELEN      32		/* length of sequence name */
#define UNTITLED_STR	"Untitled"

/* record filter (by event header) */

#define IGNOREMSG_ALLNOTESOFF			0x00000001L
#define IGNOREMSG_ALLSOUNDSOFF			0x00000002L
#define	IGNOREMSG_RESETALLCONTROLLERS	0x00000004L
#define IGNOREMSG_CHANNELMODE			(IGNOREMSG_ALLNOTESOFF|IGNOREMSG_ALLSOUNDSOFF|IGNOREMSG_RESETALLCONTROLLERS)

struct event
{
	unsigned char	 data[3];	/* midi event data */
	unsigned time;				/* time of event */
};

struct track
{
	struct  ln_node ln;
	char	name[TRACKNAMELEN];
	struct  event *data;
	int		numevents;
	int		recchnl;
	int		recbank;
	int		recpatch;
};

/* attributes for tnodes */

#define TNATTR_NORMAL	0
#define TNATTR_MUTE     1

struct tnode /* tracklist for sequence */
{
	struct ln_node ln;
	struct track *trk;
	int attr;
};

struct sequence
{
	struct  ln_node ln;
	char	name[SEQNAMELEN];	/* name + default filename */
	int		seqlen;				/* #of measures */
	int		bpmeas;				/* #beats per measure */
	int		tickbeat;   		/* #ticks per beat */
	struct	tnode tlist;  		/* tracklist base */
};

struct songnode
{
	struct	ln_node ln;
	struct	sequence *seq;
	int		mclock;/* master clock */
	int		repetitions;
};

/* list manipulating functions */

#define SUCC(x) ((void *)(((struct ln_node *)x)->succ))
#define PRED(x) ((void *)(((struct ln_node *)x)->pred))

struct ln_node *findlastnode(struct ln_node *);
struct ln_node *findfirstnode(struct ln_node *);
void            linknode(struct ln_node *, struct ln_node *);
void            unlinknode(struct ln_node *);

struct ln_node *searchnode(struct ln_node *, unsigned);
struct ln_node *nodenumber(int, struct ln_node *);

/* track functions */

struct track   *newtrack(char *);
void            deletetrack(struct track *);

/* tnode (sequence tracks) functions */

struct tnode   *newtnode(struct track *);
struct tnode   *inserttnode(struct track *, struct sequence *);
void            deletetnode(struct tnode *t);

/* songnode (song node / song sequence) functions */

struct songnode*newsnode(struct sequence *s);
struct songnode*insertsnode(struct sequence *, struct songnode *);
void			deletesnode(struct songnode *);

/* sequence functions */

struct sequence *newsequence(char *);
void deletesequence(struct sequence *);

/* misc. functions */

void			putdat(unsigned char);
void			putcom(unsigned char);

unsigned char	readbufdat(void);

void			programchange(unsigned char,unsigned char,unsigned char);

void            panic(void);
void            echoevent(unsigned char);
void            flushinpbuf(void);
void            rewindtune(void);
void            record(struct track *);
void            playtrack(struct track *);
void            record_play(struct sequence *,struct track *);
/* returns -1 on user break */
int             playsequence(struct sequence *);
void			playsong(struct songnode *);

void			transposetrack(struct track *,int);
int				aligntrack(struct track *,unsigned);
void			velocityscale(struct track *,int beginval,int endval,
					unsigned begintick, unsigned endtick);
void			monophonize(struct track *);

void            setmpuint(void);
void            restoreint0a(void);

void            settimerint(void);
void            settimerclock(unsigned);
void            restoretimerint(void);

#endif
