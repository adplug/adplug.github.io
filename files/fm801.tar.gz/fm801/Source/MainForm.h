/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#ifndef MainFormH
#define MainFormH
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>

#include "FM801.h"
#include "ccsregistry.h"

class TFormMain : public TForm
{
__published:	// IDE-managed Components
        TLabel *LabelFMSynth;
        TCheckBox *CheckBoxMute;
        TCheckBox *CheckBoxLinked;
        TTrackBar *TrackBarLeft;
        TTrackBar *TrackBarRight;
        TGroupBox *GroupBoxVolume;
        TGroupBox *GroupBoxOPL;
        TRadioButton *RadioButtonOPL2;
        TRadioButton *RadioButtonOPL3;
        TGroupBox *GroupBoxAddress;
        TComboBox *ComboBoxAddress;
        TButton *ButtonAddress;
        TLabel *LabelAddress;
        TLabel *LabelCurrentAddress;
        TLabel *LabelAddressValue;
        void __fastcall TrackBarLeftChange(TObject *Sender);
        void __fastcall TrackBarRightChange(TObject *Sender);
        void __fastcall CheckBoxLinkedClick(TObject *Sender);
        void __fastcall CheckBoxMuteClick(TObject *Sender);
        void __fastcall RadioButtonOPL2Click(TObject *Sender);
        void __fastcall RadioButtonOPL3Click(TObject *Sender);
        void __fastcall ButtonAddressClick(TObject *Sender);
private:	// User declarations
        class FM801 *fm801;
        int getPos(TTrackBar *);
        void initfm801(AnsiString);
        TTrackBar *lastChanged;
public:		// User declarations
        __fastcall TFormMain(TComponent* Owner);
        __fastcall ~TFormMain(void);
};

extern PACKAGE TFormMain *FormMain;
#endif

