#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<mem.h>
#include<math.h>
#include<dos.h>
#include<conio.h>
#include"adlib.h"
#include"fmplay.h"

extern unsigned _heaplen = 30000; /* this is a limit on song size */
extern unsigned _stklen  = 512;

void main(void)
{BYTE *song;
 song=FMLoadSong("canon2.scr");
 if (!song)
	{printf("Couldn't load song.\n");
	exit(-1);
	}
 FMInstallISR(1);
 FMStartSong(song,3,30);
 keep(0, (_SS + ((_SP+2)/16) - _psp));
}

