#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <dos.h>
#include <alloc.h>
#include <dir.h>
#include <string.h>
#include <io.h>
#include <ctype.h>

#define SMFP_INITIALIZE   0
#define SMFP_LOADTUNE     1
#define SMFP_PUTMIDIDATA  2
#define SMFP_ISR          3
#define SMF_LOADTUNE      4
#define SMF_ISR           5
#define SMF_STOPTUNE      6
#define SFX_LOADSFX       7    /* load segment of sfx */
#define SFX_PLAYSOUND     8    /* play sound */
#define SFX_STOPSFX       9    /* stop all sfx */
#define SFX_PLAYSFX      10    /* play sfx */

unsigned char huge *smf;   /* standard MIDI file */
void huge *mfp;   /* MIDI file patch    */
void huge *sfx;   /* sound FX data      */
void (huge *smfpdriver)(void);

void vgasetcolor(unsigned char reg, unsigned char value)
{
    asm {
    	mov		dx,3dah
	}
hr1:
    asm {
        in		al,dx

        and		al,1
        jnz		hr1
	}
hr2:
    asm {
        in		al,dx

        and		al,1
        jz		hr2

        mov		dx,3c0h

        mov		al,reg
		out		dx,al
        mov		al,value
        out		dx,al
        mov		al,20h
        out		dx,al
    }
}

void callsmfp(int cmd)
{
   asm push ax
   vgasetcolor(0,63);
   asm mov bx,cmd
   asm pop ax
   smfpdriver();
   vgasetcolor(0,0);
}

void huge *loadfile(char *fn,char *ext)
{
   FILE *f;
   char name[MAXPATH];
   unsigned long l;
   unsigned char far *dest;

   strcpy(name,fn);
   strcat(name,ext);
   strupr(name);
   f=fopen(name,"rb");
   if (f==0)
   {
      printf("%s not found.\n",name);
      exit(1);
   }
   l=filelength(fileno(f));
   dest=farmalloc(l+16);
   if (dest==0)
   {
      printf("Not enough memory.\n");
      exit(1);
   }
   dest = MK_FP(FP_SEG(dest)+1,0);
   {
      int c;
      unsigned char far *d;
      d=dest;

      while((c=getc(f))!=EOF)
      {
         *d++ = c;
      }
   }
   fclose(f);
   return dest;
}


void printinfo(const char *titl)
{
   clrscr();
   printf
   (
"\n\n\n\n\n\n\n"
"\t\t\t\tPlaying : %s\n"
"\n\n"
"\t\t\t\tF1      Restart\n"
"\t\t\t\tEsc     Quit\n"
"\t\t\t\t+/-     Tempo\n"
"\t\t\t\tSPACE   Stop\n"
"\t\t\t\tA-Z,0-2 Sound FX", titl
   );
}

main(int argc,char *argv[])
{
   int quit=0;
   int speed=25;
   long oldtime=0L,newtime=0L,n;

   if(argc!=2)
   {
      printf("Usage: smfptest <filename>\nRequires <filename>.MID and <filename>.MFP\n");
      exit(0);
   }
   smf=loadfile(argv[1],".MID");
   mfp=loadfile(argv[1],".MFP");
   smfpdriver=loadfile("MIDIEMU",".BIN");
   sfx=loadfile("TRODSFX",".BIN");

   printinfo(argv[1]);

   callsmfp(SMFP_INITIALIZE);

   _AX = FP_SEG(mfp);
   callsmfp(SMFP_LOADTUNE);
   _AX = FP_SEG(smf);
   callsmfp(SMF_LOADTUNE);
   _AX = FP_SEG(sfx);
   callsmfp(SFX_LOADSFX);

   do
   {
      int ch;

      while((unsigned char)inportb(0x3da)&(unsigned char)8);
      while(!(inportb(0x3da)&8));
      newtime += speed;
      delay(2);
      for(n=oldtime/25;n<newtime/25;n++)
         callsmfp(SMF_ISR);
      oldtime = newtime;
      if (kbhit())
         switch(ch=tolower(getch()))
      {
         case '+':
            if (speed<200)speed++;
            break;
         case '-':
            if (speed>1)speed--;
            break;
         case 27:
            quit=1;
            break;
         case 0:
            if (getch()==59)
            {
               callsmfp(SFX_STOPSFX);
               _AX = FP_SEG(smf);
               callsmfp(SMF_LOADTUNE);
            }
            break;
         case ' ':
            callsmfp(SMF_STOPTUNE);
            break;
         default:
            if (ch>='a'&&ch<='z')
            {
               _AX = ch-'a';
               callsmfp(SFX_PLAYSFX);
            } else
            if (ch>='0'&&ch<='2')
            {
               _AX = ch-'0'+'z'-'a'+1;
               callsmfp(SFX_PLAYSFX);
            }
      }
   } while (!quit);
   callsmfp(SFX_STOPSFX);
   callsmfp(SMF_STOPTUNE);
   return 0;
}
