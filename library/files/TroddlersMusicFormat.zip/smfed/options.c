#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>

#include "midi.h"
#include "globdat.h"
#include "scrwin.h"
#include "windata.h"
#include "inslist.h"
#include "node2win.h"

extern void livethru(void);

/*
	"Tempo",
	"Channel",
	"Instrument",
	"Quantize",
	"Velo Sens",
	"Name",
	"Transpose",
	"Align",
	"Clone",
	"Track Length",
	"Beats/Measure",
	"Ticks/Beat",
	"Count in",
    "Monophonize",
	"GS MIDI"
*/

void recordoptions(struct sequence *s,int autoval)
{
	int	v,i;
	char temps[80];
	struct tnode *tn,*newtn;
	struct track *t;

	for (;;)
	{
		if (autoval == -1)
		{
			recoptionswindow.strings = recordoptstr;
			openscrwin(&recoptionswindow);
			v=selectscrwin(&recoptionswindow,livethru);
			closescrwin(&recoptionswindow);
		} else
			v = autoval;

		switch(v)
		{
			case -1: /* non-extended */
				switch(getch())
				{
					case 27:
						goto loop_end;
				}
				break;

			case -2: /* extended */
				getch();
				break;

			case 0: 						/* tempo */
	            sprintf(temps,"Clock rate (10-200%%) (%d) : ",mclockpct);
				i = numinput(temps,3,1,200);
				if (i > 10)
				{
					mclockpct = i;
					settimerclock((mclock*i)/100);
				}
				return;

			case 1:							/* channel */
                sprintf(temps,"Record channel (%d) : ",recchnl + 1);
				i = numinput(temps,3,1,16);
				if (i > 0)
				{
					recchnl = i - 1;
					recprogram = defprog[recchnl];
					recbank    = defbank[recchnl];
					programchange(recchnl,recprogram,recbank);

					if (seqeditwindow.active == seqeditwindow.numstr) break;

					tn = (struct tnode *)
						nodenumber(seqeditwindow.active,
							SUCC(&s -> tlist.ln));

					tn->trk->recchnl   = i-1;
				}
				break;

			case 2:							/* instrument */
				if (seqeditwindow.active != seqeditwindow.numstr)
                {
					tn = (struct tnode *)
						nodenumber(seqeditwindow.active,
							SUCC(&s -> tlist.ln));

                	i = selectpatch(recchnl == 9,tn->trk->recpatch);
				}

				else i = selectpatch(recchnl == 9,0);
				if (i!=-1)
				{
                    recinstr   = defpatch[recchnl]= i;
					recprogram = defprog[recchnl] = patchlist[i].pc;
					recbank    = defbank[recchnl] = patchlist[i].bs;

					if (seqeditwindow.active ==
						seqeditwindow.numstr) break;

					tn = (struct tnode *)
						nodenumber(seqeditwindow.active,
							SUCC(&s -> tlist.ln));

					tn->trk->recpatch  = patchlist[i].pc;
					tn->trk->recbank   = patchlist[i].bs;
				}
				programchange(recchnl,defbank[recchnl],defprog[recchnl]);
				return;

			case 3:							/* Quantize */
                sprintf(temps,"Quantize value (%d) : ",quantize);
				i = numinput(temps,3,1,128);
				if (i!=-1) quantize = i;
				return;

			case 4:							/* Velocity sense */
				i = numinput("Velocity offset (1-128) : ",3,1,128);
				if (i!=-9999)
				{
					veloffs = i-1;
					i = numinput("Velocity sensitivity in % (0-100) : ",
						3,0,100);
					if (i!=-9999)
						velsens = i;
				}
				return;

			case 5: 						/* name */
				if (seqeditwindow.active == seqeditwindow.numstr) break;
				if (strinput("Track name : ",TRACKNAMELEN,temps)!=-1)
				{
					tn = (struct tnode *)
						nodenumber(seqeditwindow.active,
							SUCC(&s -> tlist.ln));
					strcpy(tn->trk->name,temps);
					freestrings(seqeditwindow.strings);
					seqeditwindow.strings =
						buildseqtracks(s);
					drawstrings(&seqeditwindow);
				}
				return;

			case 6:
				if (seqeditwindow.active == seqeditwindow.numstr) break;
				i = numinput("Transpose track by (-12 - 12) : ",3,-12,12);
				if ((i != -9999)&&(i!=0))
				{
					tn = (struct tnode *)
						nodenumber(seqeditwindow.active,
							SUCC(&s -> tlist.ln));
					transposetrack(tn->trk,i);
				}
				return;

			case 7:										/* align */
				if (seqeditwindow.active == seqeditwindow.numstr) break;
				tn = (struct tnode *)
					nodenumber(seqeditwindow.active,
						SUCC(&s -> tlist.ln));
				i = aligntrack(tn->trk, seqlen*tickbeat*bpmeas);

				if (i>0)
				{
					sprintf(temps,"%d noteon events aligned.",i);
					outmsg(temps);
				} else
					outmsg("Track is already aligned.");
				return;

			case 8:										/* clone */
				if (seqeditwindow.active == seqeditwindow.numstr) break;
				tn = (struct tnode *)
					nodenumber(seqeditwindow.active,
						SUCC(&s -> tlist.ln));

				t = newtrack("");

				t->recchnl  = tn->trk->recchnl;
				t->recpatch = tn->trk->recpatch;
				t->recbank  = tn->trk->recbank;
				t->numevents= tn->trk->numevents;

				memcpy(t->data,tn->trk->data,
					tn->trk->numevents*sizeof(struct event));

				strcpy(t->name,"Clone:");
				strncat(t->name,tn->trk->name,TRACKNAMELEN-8);

				newtn = inserttnode(t,s);

				/* link manually at old node's place in list */

				unlinknode(&newtn->ln);
				linknode(&newtn->ln,&tn->ln);

				unlinknode(&tn->ln);
				deletetnode(tn);

				freestrings(seqeditwindow.strings);
				seqeditwindow.strings =
					buildseqtracks(s);
				drawstrings(&seqeditwindow);
				outmsg("Track cloned.");
				return;

            case 9:										/* len in measures */
                sprintf(temps,"Length in measures (%d) : ",seqlen);
			    v = numinput(temps,3,1,999);
			    if (v>0)
			    {
				    seqlen = v;
            	    if (seqeditwindow.active != seqeditwindow.numstr)
	                	s->seqlen = v;
                }
			    break;

			case 10:
                sprintf(temps,"Beats per measure (%d) : ",bpmeas);
			    v = numinput(temps,2,1,64);
			    if (v>0)
				{
					bpmeas = v;
            	    if (seqeditwindow.active != seqeditwindow.numstr)
	                	s->bpmeas = v;
                }
			    break;

			case 11:
                sprintf(temps,"Ticks per beat (%d) : ",tickbeat);
			    v = numinput(temps,3,1,999);
			    if (v>0)
				{
					tickbeat = v;
            	    if (seqeditwindow.active != seqeditwindow.numstr)
	                	s->tickbeat = v;
                }
			    break;

			case 12:									 /* velo scale */
				if (seqeditwindow.active == seqeditwindow.numstr) break;
				tn = (struct tnode *)
					nodenumber(seqeditwindow.active,
						SUCC(&s -> tlist.ln));

				i = numinput("Begin value (0-200) : ",3,0,200);
				if (i!=-9999)
				{
					v = numinput("End value (0-200) : ",3,0,200);
					if (i!=-9999)
					{
						velocityscale(tn->trk,i,v,0,seqlen*bpmeas*tickbeat);
						outmsg("Velocity has been changed.");
					}
				}
				return;

			case 13:									/* count in */
				i = numinput ("Count-in measures (0-4) : ",
					2,0,4);
				if (i != -9999)
					countin = i;
				return;

			case 14:									/* monophonize */
				if (seqeditwindow.active == seqeditwindow.numstr) break;
				tn = (struct tnode *)
					nodenumber(seqeditwindow.active,
						SUCC(&s -> tlist.ln));
				monophonize(tn->trk);
				return;

			case 15:		/* switch between GS or standard MIDI */
				gs = !gs;
        		if (gs) outmsg("GS output on");
                else outmsg("GS output off");
				break;
		}
		if (autoval != -1) break;
	}
loop_end:
}
