#include <stdlib.h>
#include <stdio.h>
#include <dos.h>

/*#include "fm_instr.h"
  */
#define ADLIB_VOICES 9

unsigned char adlib_data[256];
void write_adlib(unsigned char r, unsigned char v)
    {
    int i;
    outp(0x388,r);
    for (i=0; i<6; i++) inp(0x388);
    outp(0x389,v);
    for (i=0; i<35; i++) inp(0x388);
    adlib_data[r]=v;
    }

/*
 46
  */

#define INS_AMP 0
#define INS_VIB 1
#define INS_EG  2
#define INS_KSR 3
#define INS_MUL 4
#define INS_KSL 5
#define INS_ATT 6
#define INS_DEC 7
#define INS_SUS 8
#define INS_REL 9
#define INS_WAV 10
#define INS_FB  11
#define INS_ALG 12


/*
    29 - Operator 1  AM/VIB/EG/KSR/Multiplier
    2C - Operator 2  AM/VIB/EG/KSR/Multiplier
    49 - Operator 1  KSL/Output Level
    4C - Operator 2  KSL/Output Level
    69 - Operator 1  Attack/Decay
    6C - Operator 2  Attack/Decay
    89 - Operator 1  Sustain/Release
    8C - Operator 2  Sustain/Release
    A4 -             Frequency (low 8 bits)
    B4 -             Key On/Octave/Frequency (high 2 bits)
    C4 -             Feedback/Connection Type
    E9 - Operator 1  Waveform
    EC - Operator 2  Waveform
  */


unsigned char adlib_opadd[] = {
	 0x00  ,0x01 ,0x02  ,0x08  ,0x09  ,0x0A  ,0x10 ,0x11  ,0x12 };


int ops[] = {
	0x20,0x20,0x40,0x40,0x60,0x60,0x80,0x80,0xe0,0xe0,0xc0 };


void fm_instrument(int voice, unsigned char *inst)
    {
    int i;
	write_adlib(0x20+adlib_opadd[voice],inst[0]);
	write_adlib(0x23+adlib_opadd[voice],inst[1]);

	write_adlib(0x40+adlib_opadd[voice],inst[2]);

	if ((inst[10] & 1)==0)
		write_adlib(0x43+adlib_opadd[voice],inst[3]);
		else
		write_adlib(0x43+adlib_opadd[voice],0);

	write_adlib(0x60+adlib_opadd[voice],inst[4]);
	write_adlib(0x63+adlib_opadd[voice],inst[5]);
	write_adlib(0x80+adlib_opadd[voice],inst[6]);
   /* write_adlib(0x80+adlib_opadd[voice],inst[7]);*/
    write_adlib(0x83+adlib_opadd[voice],inst[7]);
	write_adlib(0xe0+adlib_opadd[voice],inst[8]);
	write_adlib(0xe3+adlib_opadd[voice],inst[9]);

	write_adlib(0xc0+voice,inst[10]);
    }

int fnums[] = {
0x16b,0x181,0x198,0x1b0,0x1ca,0x1e5,0x202,0x220,0x241,0x263,0x287,0x2ae
		  };

void fm_playnote(int voice, int note, int volume)
	{
	int nsc=-6;
	int freq=fnums[(note+nsc)%12];
	int oct=(note+nsc)/12;
	int c;
	int vol=volume*63/255;

   write_adlib(0x43+adlib_opadd[voice], (63-vol) |
		(adlib_data[0x43+adlib_opadd[voice]]&0xc0));


   if (!(adlib_data[0xc0+voice] & 1))
		write_adlib(0x40+adlib_opadd[voice], (63-vol) |
			(adlib_data[0x40+adlib_opadd[voice]]&0xc0));


	write_adlib(0xa0+voice,freq&0xff);

	c=((freq&0x300) >> 8)+(oct<<2) + (1<<5);
	write_adlib(0xb0+voice,c);
    }

void fm_endnote(int voice)
    {
	write_adlib(0xb0+voice,0);
    }

void fm_reset()
    {
    int i;
    for (i=0; i<256; i++)
        write_adlib(i,0);

	write_adlib(0x01, 0x20);
	write_adlib(0xBD,0xc0);
    }
