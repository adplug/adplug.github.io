#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <mem.h>
#include <string.h>
#include <alloc.h>

#include "scrwin.h"
#include "windata.h"
#include "insedit.h"
#include "adlib.h"
#include "patchdat.h"
#include "inslist.h"
#include "drumset.h"
#include "midi.h"
//#include "globdat.h"
#include "file.h"

extern unsigned char channelmaxvoice[];
extern unsigned char channelpriority[];

int loadpatchdata(char *fn)
{
	FILE *f;

   if ((f=fileopen(fn,"rb"))==NULL)return -1;

	fread(_patchtable,sizeof(struct patchcomp),256,f); /* tone reference table */
	fseek(f,sizeof(struct patch)*512,SEEK_CUR);
	fseek(f,16*256,SEEK_CUR);
	fread(drumins,128,1,f);
	fread(drumnote,128,1,f);
   fread(channelmaxvoice,16,1,f);
   fread(drumpriority,128,1,f);
   fread(channelpriority,16,1,f);
   fileclose(f);
	return 0;
}

int savepatchdata(char *fn)
{
   FILE *f;
   if ((f=fileopen(fn,"wb"))==0)return -1;
	fwrite(_patchtable,sizeof(struct patchcomp),256,f); /* tone reference table */
	fseek(f,sizeof(struct patch)*512,SEEK_CUR);
	fseek(f,16*256,SEEK_CUR);
	fwrite(drumins,128,1,f);
	fwrite(drumnote,128,1,f);
   fwrite(channelmaxvoice,16,1,f);
   fwrite(drumpriority,128,1,f);
   fwrite(channelpriority,16,1,f);
   fileclose(f);
   return 0;
}
