void vertline(int x1,int y1,int y2,int color);
void horizline(int x1,int y1,int x2,int color);
void bar(int x1,int y1,int x2,int y2,int color);
void putpixel(int x,int y,int color);
void grinit(void);
void textinit(void);

