void vgasetcolor(unsigned char reg, unsigned char value)
{
    asm {
    	mov		dx,3dah
	}
hr1:
    asm {
        in		al,dx

        and		al,1
        jnz		hr1
	}
hr2:
    asm {
        in		al,dx

        and		al,1
        jz		hr2

        mov		dx,3c0h

        mov		al,reg
		out		dx,al
        mov		al,value
        out		dx,al
        mov		al,20h
        out		dx,al
    }
}