/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#include <vcl.h>
#pragma hdrstop
#include "MainForm.h"
#pragma package(smart_init)
#pragma resource "*.dfm"

TFormMain *FormMain;

__fastcall TFormMain::TFormMain(TComponent* Owner) : TForm(Owner)
{
        fm801=NULL;
        class CCSRegistry *ccsreg= new CCSRegistry();
        ComboBoxAddress->Text= IntToHex(ccsreg->GetPortAddress(), 4);
        delete ccsreg;
}

__fastcall TFormMain::~TFormMain(void)
{
        if(fm801!=NULL) delete fm801;
}

void TFormMain::initfm801(AnsiString hexAddress)
{
        if(fm801!=NULL) delete fm801;

        USHORT baseAddress= StrToInt( hexAddress );

        fm801= new FM801(baseAddress);
        if(fm801==NULL)
                throw "Couldn't create an fm801 instance";

        BOOLEAN muted;
        BYTE leftvol, rightvol;

        fm801->readFmVol(muted, leftvol, rightvol);

        if(muted)
                CheckBoxMute->Checked=true;
        else
                CheckBoxMute->Checked=false;

        TrackBarLeft->Position = leftvol;
        TrackBarRight->Position= rightvol;

        if(leftvol == rightvol)
                CheckBoxLinked->Checked=true;
        else
                CheckBoxLinked->Checked=false;

        LabelAddressValue->Caption=hexAddress;
        RadioButtonOPL2->Checked= false;
        RadioButtonOPL3->Checked= true;
        RadioButtonOPL2->Enabled= true;
        RadioButtonOPL3->Enabled= true;
        TrackBarLeft->Enabled=true;
        TrackBarRight->Enabled=true;
        CheckBoxLinked->Enabled=true;
        CheckBoxMute->Enabled=true;
        lastChanged=TrackBarLeft;
}

int TFormMain::getPos(TTrackBar *Tb)
{
        int pos= Tb->Position;
        if(pos<0)
                pos= 0;
        else if(pos>31)
                pos= 31;
        return pos;
}

void __fastcall TFormMain::TrackBarLeftChange(TObject *Sender)
{
        if( CheckBoxLinked->Checked )
                TrackBarRight->Position= TrackBarLeft->Position;

        lastChanged=TrackBarLeft;

        if(fm801!=NULL) fm801->writeFmVol( getPos(TrackBarLeft), getPos(TrackBarRight) );
}

void __fastcall TFormMain::TrackBarRightChange(TObject *Sender)
{
        if( CheckBoxLinked->Checked )
                TrackBarLeft->Position= TrackBarRight->Position;

        lastChanged=TrackBarRight;

        if(fm801!=NULL) fm801->writeFmVol( getPos(TrackBarLeft), getPos(TrackBarRight) );
}

void __fastcall TFormMain::CheckBoxLinkedClick(TObject *Sender)
{
        if(lastChanged==TrackBarLeft)
                TrackBarRight->Position= TrackBarLeft->Position;
        else
                TrackBarLeft->Position= TrackBarRight->Position;
}

void __fastcall TFormMain::CheckBoxMuteClick(TObject *Sender)
{
        if(fm801==NULL) return;
        if(CheckBoxMute->Checked)
                fm801->muteFmVol();
        else
                fm801->unmuteFmVol();
}

void __fastcall TFormMain::RadioButtonOPL2Click(TObject *Sender)
{
        if(fm801!=NULL) fm801->opl3->opl2on();
}

void __fastcall TFormMain::RadioButtonOPL3Click(TObject *Sender)
{
        if(fm801!=NULL) fm801->opl3->opl3on();
}

void __fastcall TFormMain::ButtonAddressClick(TObject *Sender)
{
        if(ComboBoxAddress->Text == "")
                return;
                
        AnsiString hexAddress= "0x"+ComboBoxAddress->Text;

        char title[1024];
        wsprintf( title, "Please confirm this I/O address [%s]", hexAddress.c_str());

        AnsiString text="Press OK if you are sure that " + hexAddress + " is the correct I/O resource address of your fm801 card.\n\n" +
                "If this address is incorrect then your computer may malfunction.\n\n" +
                "You can determine the resource I/O address from within the system device manager.";

        int response= MessageBox(this->Handle, text.c_str(), title, MB_OKCANCEL);

        if(response!=IDOK)
                return;

        initfm801(hexAddress);
}
