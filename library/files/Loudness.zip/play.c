#include <stdio.h>
#include <conio.h>
#include <io.h>

#include "adlib.h"

unsigned char piano[] =
		{
		0x21,0x21, 0x8f, 0x0c, 0xf2, 0xf2, 0x45, 0x76,
		0x00,0x00, 0x08
		};

#define LOUDNESS_INS  46L
#define MAX_LOUDNESS_INS 32
#define PATTERN_LEN  27
#define LDS_VOICES 9


unsigned char alldata[7000];
unsigned char idata[MAX_LOUDNESS_INS][LOUDNESS_INS];
unsigned char total_ins;
unsigned int pdata[100][LDS_VOICES][2];
unsigned char *dptr;
unsigned char *mptr;

int total_patterns;

#define PPDATA_NOTE    2
#define PPDATA_VOICE   1
#define PPDATA_VOLUME  0

#define PATTERN_ROWS  24
#define DEFAULT_LEN    1

unsigned char prepared_pattern[PATTERN_ROWS][LDS_VOICES][3];

void make_pat(int p)
    {
    int i,j,k,n,m;
	int dnum[9][2];

    for (i=0; i<PATTERN_ROWS; i++)
        for (j=0; j<LDS_VOICES; j++)
            for (k=0; k<4; k++)
                prepared_pattern[i][j][k]=0;
    
    for (j=0; j<LDS_VOICES; j++)
        {
		/*dnum[j][0]=-DEFAULT_LEN;*/
        dnum[j][0]=-1;
		dnum[j][1]=DEFAULT_LEN;
        }

    for (n=0; n<PATTERN_ROWS; n++)
        {
        for (j=0; j<LDS_VOICES; j++)
				{
				m=pdata[p][j][0]+(n*4);

				/*
				for (k=0; k<4; k++)
					printf("%02x",(int)mptr[m+k]);
				if ((j%LDS_VOICES)!=8) printf("|");
				*/
                if (dnum[j][0]<PATTERN_ROWS)
					{
                    dnum[j][1]=DEFAULT_LEN; 
					if (mptr[m+2]!=0)
						dnum[j][1]=mptr[m+2];
					dnum[j][0]+=dnum[j][1];

					if (dnum[j][0]>=0 & dnum[j][0]<PATTERN_ROWS)
						{
						prepared_pattern[dnum[j][0]][j][PPDATA_VOLUME]=mptr[m+3];
						prepared_pattern[dnum[j][0]][j][PPDATA_VOICE]=mptr[m+0];
						prepared_pattern[dnum[j][0]][j][PPDATA_NOTE]=mptr[m+1];
						}
                    }
				}
        }
    }
                



unsigned char fins[11];
int ldord[] =
	{
	1,6,2,7,3,8,4,9, 5,10,11
	};


main(int argv, char *args[])
	{
	FILE *stream;
	long i,l,j;
	int m,n,o,p,q;
	char s[80];

	unsigned char a,b,c,d;
    unsigned char voice,volume,note;

    if (argv<2)
        {
        printf ("loudfile: ");
        scanf("%s",s);
        }
        else
		sprintf (s,args[1]);

	fm_reset();
	for (i=0; i<9; i++)
		fm_instrument(i,piano);

	stream=fopen(s,"rb");
    l=filelength(fileno(stream));
	fread(alldata,1L,l,stream);
	fclose(stream);
    
	for (i=0; i<15; i++)
		printf ("%02x ",(int)alldata[i]);

	printf ("\n");
    total_ins=alldata[15];
    printf ("%d instruments\n",(int)total_ins);

	for (i=0; i<total_ins; i++)
		{
		printf ("\nloading ins %2d:===> ",i);
		for (j=0; j<11; j++)
			{
            idata[i][j]=alldata[16+(i*LOUDNESS_INS)+ldord[j]];
			printf("%2x ",idata[i][j]);
			}
		}

	total_patterns=alldata[16+(total_ins*LOUDNESS_INS)+1];
	printf ("\n%d patterns\n",total_patterns);

	dptr=&alldata[16+(total_ins*LOUDNESS_INS)+3];

    for (j=0; j<total_patterns; j++)
        {
		for (i=0; i<LDS_VOICES; i++)
			{
			m=(int)dptr[j*PATTERN_LEN+(i*3)+2];
			n=((int)dptr[j*PATTERN_LEN+(i*3)+1]<<8) +
			  ((int)dptr[j*PATTERN_LEN+(i*3)+0]);

			pdata[j][i][0]=n;
			pdata[j][i][1]=m;
			printf (" %4x %2x",n,m);
            }
		printf ("\n");
        }

	/* note:
		the two bytes between the patterns and music
		data specify how many bytes of music data is there..
		since i've already loaded it all into mem, who cares.. */

	mptr=&alldata[16+(total_ins*LOUDNESS_INS)+3+(total_patterns*PATTERN_LEN)+2];

	printf("\n\n");

	for (i=0; i<total_patterns; i++)
        {
		printf ("\n\npattern %d\n",(int)i);
		make_pat(i);

		/*
		for (j=0; j<LDS_VOICES; j++)
			fm_endnote(j);
		*/

        for (n=0; n<PATTERN_ROWS; n++)
            {
            for (j=0; j<LDS_VOICES; j++)
                {
				volume=prepared_pattern[n][j][PPDATA_VOLUME];
				voice=prepared_pattern[n][j][PPDATA_VOICE];
				note=prepared_pattern[n][j][PPDATA_NOTE];
                
				printf ("%2x %2x %2x",(int)volume,(int)voice,(int)note);
                if (j!=8) printf("|");

                if (note!=0)
					{
					fm_endnote(j);
					if (voice<total_ins)
						fm_instrument(j,idata[voice]);
					fm_playnote(j,note,0xa0);
                    }
                }
            c=getch();
            if (c=='q') n=PATTERN_ROWS;
            }
        if (c=='q') i=total_patterns;
        }

	fm_reset();
	}


