#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>

#include "midi.h"
#include "scrwin.h"
#include "windata.h"
#include "events.h"
#include "node2win.h"

static char **eventstr=NULL;

#define EVENTSTRLEN 50

void listevents(struct track *t)
{
	struct event *evp;
	int	i;
	unsigned lasteventtime=65534u;
	unsigned char d1,d2,d3,dt;
	char **estrp;

	freestrings(eventstr);

	estrp = eventstr = calloc(sizeof(void *),MAXTRACKEVENTS);
   if (estrp==0)memerr();

	evp = t->data;

	for (i=0;i<t->numevents;i++,evp++)
	{
		*estrp = malloc(EVENTSTRLEN);
      if (*estrp==0) memerr();

		d1 = evp->data[0];
		d2 = evp->data[1];
		d3 = evp->data[2];
		dt = d1 & 0xf0;

		if (d1 < 0xa0) /* noteon/off event */
		{
			if (dt == 0x90) /* including header */
			{
				d1 = d2;	/* ignore it */
				d2 = d3;
			}
			if (d2 == 0) 	/* velo = 0, noteoff */
				sprintf(*estrp,"%5d   %02xh   NOTEOFF",
					evp->time,d1);
			else
				sprintf(*estrp,"%5d   %02xh   %02xh",
					evp->time,d1,d2);
		} else
		{
			if ((dt == 0xb0) && (d2 == 0x7b))
				sprintf(*estrp,"%5d           ALL NOTES OFF",
					evp->time);

			else if ((dt == 0xb0) && (d2 == 0x40))
			{
				if (d3 != 0)
				sprintf(*estrp,"%5d   %02xh   HOLD1 ON",
					evp->time,d3);
				else
				sprintf(*estrp,"%5d         HOLD1 OFF",
					evp->time);
			}
			else if (evp->time == (unsigned)-1)
				sprintf(*estrp,"---           END");

			else
				sprintf(*estrp,"%5d   %02xh   %02xh   %02xh",
					evp->time,d1,d2,d3);
		}
		if (evp->time == lasteventtime) /* remove event time repeats */
			memset(*estrp,' ',5);

		else lasteventtime = evp->time;

		estrp++;
	}
	*estrp = NULL;
	eventlistwindow.strings = eventstr;

	openscrwin(&eventlistwindow);
	if (selectscrwin(&eventlistwindow,NULL)<0)
		getch();
	closescrwin(&eventlistwindow);
}
