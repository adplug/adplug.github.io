#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <xtypes.h>

#include "globdat.h"
#include "midi.h"
#include "saveload.h"
#include "midiemu.h"
#include "insedit.h"
#include "file.h"
#include "adlib.h"  /* module includes definition of hw_saveinstruments */

static char	sng_directory[]="",
			ins_directory[]="",
			pat_directory[]="";


int loadsong(char *filename, struct songnode *sn)
{
	FILE	*f;
	char	*strp;
	char	name[max(SEQNAMELEN,TRACKNAMELEN)];
	struct	sequence *s;
	struct	tnode *tn;
	struct	songnode *snode,*sntemp;
	struct	track *t;
	int		nodenumber;

	sntemp = sn;

	f=fileopen(filename,"rb");
	if (f == NULL) return -1;

	mclock = getw(f);								/* read master clock	*/
	mclockpct=getw(f);
	seqnumserial=getw(f);
	nodeserialnumber=getw(f);

	while ((unsigned)(nodenumber = getw(f))
			!= 0xffff)								/* read snode number	*/
	{
		snode = insertsnode((struct sequence*)
					NULL,sn);						/* no sequence link		*/
		snode -> ln.number = nodenumber;
		snode -> repetitions = getw(f);				/* get repetitions		*/
		sn = snode;
	}
	while ((unsigned)(nodenumber = getw(f))!= 0xffff)			/* read sequence number */
	{
		strp = name;
		while((*strp++ = getc(f))!='\0');			/* read sequence name	*/
		s = newsequence(name);						/* allocate sequence	*/
		s -> ln.number = nodenumber;				/* set node number		*/
		s -> seqlen    = getw(f);					/* get sequence length	*/
		s -> bpmeas    = getw(f);					/* get beats/measure	*/
		s -> tickbeat  = getw(f);					/* get ticks/beat		*/

		while ((unsigned)(nodenumber = getw(f))!= 0xffff)/* read tnode for seq	*/
		{
			tn=inserttnode((struct track *)NULL,s);	/* link node to seq		*/
			tn->ln.number = nodenumber;				/* linked track's node	*/
			tn->attr = getw(f);
		}
	}
	while ((unsigned)(nodenumber = getw(f))!= 0xffff)			/* get track's nodenum	*/
	{
		strp = name;
		while((*strp++ = getc(f))!='\0');			/* read track name		*/
		t = newtrack(name);							/* allocate track		*/
		t -> numevents = getw(f);					/* read number of events*/
		t -> recchnl   = getw(f);					/* read default channel */
		t -> recbank   = getw(f);
		t -> recpatch  = getw(f);
		t -> ln.number = nodenumber;				/* set node number		*/
		fread(t -> data,							/* read event data		*/
			sizeof(struct event),
			t -> numevents+1, f);
	}

	fileclose(f);

	/* create links between tlists and track structs */

	s = SUCC(&seq.ln);

	while (s != NULL)
	{
		tn = SUCC(&s->tlist.ln);		/* 1st is NT_START */
		while (tn != NULL)
		{
			nodenumber = tn -> ln.number; /* node number of track to link with */

			t = (struct track *)
					searchnode(&trk.ln,nodenumber);	/* find track */
			tn -> trk = t;
			tn = SUCC(&tn->ln);
		}
		s = SUCC(&s->ln);
	}

	/* create links between songnodes and sequences */

	sn = sntemp;

	snode = SUCC(&sn->ln);

	while (snode != NULL)
	{
		nodenumber = snode -> ln.number;

		s = (struct sequence *)
				searchnode(&seq.ln,nodenumber);			/* find sequence */
		snode -> seq = s;
		snode = SUCC(&snode -> ln);
	}
	settimerclock((mclock*mclockpct)/100);

	return 0;
}

void loadmusicdata(char *songname, struct songnode *loadto)
{
	char filename[120];

	strcpy(filename,sng_directory);
	strcat(filename,songname);
	strcat(filename,SONG_FNEXTENSION);
	loadsong(filename,loadto);

	strcpy(filename,ins_directory);
	strcat(filename,songname);
	strcat(filename,INS_FNEXTENSION);
	hw_loadinstruments(filename);

	strcpy(filename,pat_directory);
	strcat(filename,songname);
	strcat(filename,PATCH_FNEXTENSION);
	loadpatchdata(filename);
}
