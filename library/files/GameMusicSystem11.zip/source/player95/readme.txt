This is the source code for the Windows 95 player program. As mentioned
elsewhere, it doesn't work too good, and I really wouldn't use it if I were
you. It is provided for the adventurous.

- Roland Acton
