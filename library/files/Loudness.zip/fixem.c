#include <stdio.h>
#include <io.h>

FILE *stream;

unsigned char data[10000];

main(int argv, char *argc[])
    {
    long i,l;
    printf(argc[1]);
    stream=fopen(argc[1],"rb");
    l=filelength(fileno(stream));
    fread(data,1,l,stream);
    data[1]=0;
    fclose(stream);
    stream=fopen(argc[1],"wb");
    fwrite(data,1,l,stream);
    fclose(stream);
    }
        


