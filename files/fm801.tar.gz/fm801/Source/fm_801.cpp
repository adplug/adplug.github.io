/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#include <vcl.h>
#include "giveio.h"
#pragma hdrstop

USEFORM("MainForm.cpp", FormMain);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 giveio();

                 Application->Initialize();
                 Application->Title = "fm801";
                 Application->CreateForm(__classid(TFormMain), &FormMain);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                Application->ShowException(&exception);
        }
        catch (...)
        {
                try
                {
                        throw Exception("");
                }
                catch (Exception &exception)
                {
                         Application->ShowException(&exception);
                }
        }
        return 0;
}
