#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>

#include "midi.h"
#include "globdat.h"
#include "scrwin.h"
#include "windata.h"
#include "inslist.h"
#include "node2win.h"

extern void livethru(void);

