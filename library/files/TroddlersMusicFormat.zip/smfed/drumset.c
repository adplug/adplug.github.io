#include "drumset.h"

unsigned char	drumins[128];
unsigned char	drumnote[128];
unsigned char drumpriority[128];