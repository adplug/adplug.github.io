#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <alloc.h>
#include <string.h>

#include "inslist.h"
#include "scrwin.h"
#include "midi.h"
#include "globdat.h"
#include "insedit.h"
#include "file.h"

static char patchlistname[32] = "Patch List";
static char drumlistname[32]  = "Drum Sets";

struct patch	 	 *patchlist    = NULL;
char 				**patchliststr = NULL;

struct patch		 *drumlist     = NULL;
char                **drumliststr  = NULL;

char patchfilename[] = "mt32.mod";
char drumfilename[]  = "scc-1drm.mod";

struct scrwindow patchlistwindow =
{
	{NULL},
	52,2,76,23,
	NULL,/* string list */
	NULL,
	LIGHTGRAY,BLUE,
	0,0
};
struct scrwindow drumlistwindow =
{
	{NULL},
	52,2,76,23,
	NULL,/* string list */
	NULL,
	LIGHTGRAY,BLUE,
	0,0
};

int  readpatchentries(FILE *f, char **ls, struct patch *ilp)
{
    int	i=0;
    char l[80];

	fgets(l,32,f);

	while(fgets(l,80,f)!=NULL)
	{
        i++;
		sscanf(l,"%d%d %[^\n]s",&ilp->bs,&ilp->pc,ilp->name);
		*ls++ = ilp->name;
		ilp++;
	}
    while (i<PATCHLISTMAXINSTR)
    {
    	strcpy(ilp->name,"Unused");
        ilp->bs = -1;
        ilp->pc = i;
        *ls++ = ilp->name;
    	ilp++;
    	i++;
    }
	*ls = NULL;
	return 0;
}

int	readdrumentries(FILE *f, char **ls, struct patch *ilp)
{
    char l[80];

	fgets(l,80,f);

	while(fgets(l,80,f)!=NULL)
	{
		sscanf(l,"%d%d %[^\n]s",&ilp->bs,&ilp->pc,ilp->name);
		*ls++ = ilp->name;
		ilp++;
	}
	*ls = NULL;
	return 0;
}

void loadpatchlist(void)
{
	char **ls;
	struct patch *ilp;
	FILE *f;

    /*	allocate memory for standard patch names and data */

	if (patchlist != NULL) free(patchlist);
	if (patchliststr != NULL) free(patchliststr);

	ilp = patchlist    = calloc(sizeof(struct patch),PATCHLISTMAXINSTR);
   if (ilp==0)memerr();
	ls  = patchliststr = calloc(sizeof(void *),PATCHLISTMAXINSTR);
   if (ls==0)memerr();

	f=fileopen(patchfilename,"rt");
	if (f==NULL) return;
    readpatchentries(f,ls,ilp);
	fileclose(f);

	patchlistwindow.title   = patchlistname;
	patchlistwindow.strings = patchliststr;



    /*	allocate memory for drum set patch names and data */

	if (drumlist != NULL) free(drumlist);
	if (drumliststr != NULL) free(drumliststr);

	ilp = drumlist    = calloc(sizeof(struct patch),PATCHLISTMAXINSTR);
   if (ilp==0)memerr();
	ls  = drumliststr = calloc(sizeof(void *),PATCHLISTMAXINSTR);
   if (ls==0)memerr();

	f=fileopen(drumfilename,"rt");
	if (f==NULL) return;
    readdrumentries(f,ls,ilp);
	fileclose(f);

	drumlistwindow.title   = drumlistname;
	drumlistwindow.strings = drumliststr;
}

static int patchbelowcursor = -1; /* test patches while selecting */

void liveselectpatch(void)
{
	int	active;

	active = patchlistwindow.active;
	if ((active != patchbelowcursor) &&
		(active != patchlistwindow.numstr))
	{
        if (gs)
		{
			putdat(0xb0|recchnl);
			putdat(0x00);
			putdat(patchlist[active].bs); /* send bank select */
        }

		putdat(0xc0|recchnl);
		putdat(patchlist[active].pc); /* program change */
		patchbelowcursor = active;
	}
	echoevent(recchnl);
}

int	selectpatch(BOOL isdrumset, int deflt)
{
	int	v;
    struct scrwindow *scrw;

    if (!isdrumset) scrw = &patchlistwindow;
    else scrw = &drumlistwindow;

	patchbelowcursor=-1;

    scrw->active = deflt;

	openscrwin(scrw);
	for (;;)
	{
		v=selectscrwin(scrw,liveselectpatch);
		switch(v)
		{
			case -1 : /* normal keystroke */
				switch(getch())
				{
					case 'e':
						v = scrw->active;
						if (v != scrw->numstr)
						{
                            if (isdrumset == TRUE)
                            	editdrumset();
							else editpatch(patchlist[v].pc);
                        }
						break;

					case 27 : /* esc */
						closescrwin(scrw);
						return(-1);

                	case 'n':
                        if (scrw->active != scrw->numstr)
						{
							strinput("Patch name: ",
								PATCHNAMELEN,
								patchlist[scrw->active].name);
                        	patchdirty = 1;
                        }
                		break;
				}
				break;
			case -2 : /* extended keystroke */
				getch();
				break;
			default :
				if (v != scrw->numstr)
				{
					closescrwin(scrw);
					return(v);
				}
		}
	}
}
