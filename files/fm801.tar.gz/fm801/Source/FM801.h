/*
Copyright (c) 2005 wlan.kewl.org Project
All rights reserved.

Licensed under the terms of the BSD license, see file LICENSE
for details.
*/

#ifndef fm801H
#define fm801H
#include <Classes.hpp>

#define FM801_FMOUTVOL  (0x0002)
#define FM801_PLAYCTRL  (0x0008)
#define FM801_I2SCTRL   (0x0024)

#define FM801_GENCTRL   (0x0054)
#define _SPDIF_ENABLE   (4)

#define FM801_OPL3      (0x0068)

#include "opl3.h"

class FM801
{
        private:
                USHORT FM801Base;
        protected:
        public:
                class OPL3 *opl3;

                FM801(USHORT);
                ~FM801(void);

                void writeFmVol(BYTE, BYTE);
                void readFmVol(BOOLEAN &, BYTE &, BYTE &);
                void muteFmVol(void);
                void unmuteFmVol(void);
};
#endif
