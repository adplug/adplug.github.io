#include <conio.h>
#include <stdlib.h>
#include <alloc.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "scrwin.h"

extern void livethru(void);

int getkey(void)
{
	while(!kbhit()) livethru();
    return getch();
}

void winactivate(struct scrwindow *w)
{
	window(w->left,w->top,w->right,w->bottom+1);
}

void drawframe(struct scrwindow *w)
{
	int	i;

	winactivate(w);

	gotoxy(1,1);
	putch(218);
	for (i=2;i<w->width;i++)
		putch(196);
	putch(191);

	for (i=2;i<w->height;i++)
	{
		gotoxy(1,i);
		putch(179);
		gotoxy(w->width,i);
		putch(179);
	}
	gotoxy(1,w->height);
	putch(192);
	for (i=2;i<w->width;i++)
		putch(196);
	putch(217);
	gotoxy(3,1);
	putch(' ');
	cputs(w->title);
	putch(' ');
}

void drawscrwinstring(struct scrwindow *w,int strnum)
{
	int	yp;
	static char fmt[8]=" %";

	yp = strnum - w->topstring + 2;
	if (yp < 2) return;

	if (yp > w->height-1) return;
	gotoxy(2,yp);
	sprintf(fmt+2,"-%ds",w->width-3);
	if (strnum == w->active)
	{
		textcolor(w->bground);
		textbackground(w->fground);
	} else
	{
		textcolor(w->fground);
		textbackground(w->bground);
	}
	if (w->strings[strnum]!=NULL)
	{
		cprintf(fmt,w->strings[strnum]);
		if (w->hilited != NULL)
		{
			gotoxy(3+w->hilited[strnum],yp);
			if (strnum != w->active)
				textcolor(w->fground ^0x8);
			else
				textcolor(w->bground ^0x8);
			putch(w->strings[strnum][w->hilited[strnum]]);
		}
	}
	else
		cprintf(fmt,"");
}

void drawstrings(struct scrwindow *w)
{
	int	sn=0;
	char **s;

	s=w->strings;
	if (s == NULL) return;

	winactivate(w);

	while (*s++ != NULL)
		drawscrwinstring(w,sn++);
	drawscrwinstring(w,sn);
	w->numstr=sn;
}

void openscrwin(struct scrwindow *w)
{
   window(1,1,80,25);
   gotoxy(70,25);
   cprintf(" %ld ",coreleft());

	textcolor(w->fground);
	textbackground(w->bground);
	w->width = w->right-w->left+1;
	w->height= w->bottom-w->top+1;
	w->below = malloc(w->width*w->height*2);
   if (w->below==0) memerr();

	gettext(w->left,w->top,w->right,w->bottom,w->below);
	window(w->left,w->top,w->right,w->bottom);
	clrscr();
	drawframe(w);
	drawstrings(w);
}

void closescrwin(struct scrwindow *w)
{
	puttext(w->left,w->top,w->right,w->bottom,w->below);
	free(w->below);
}

void scrnewactive(struct scrwindow *w, int newact)
{
	int	old;

	old = w->active;

	if (newact > w->numstr) newact = w->numstr;
	if (newact < 0) newact = 0;

	w->active = newact;
	drawscrwinstring(w,old);
	if (newact < w->topstring)
	{
		w->topstring = newact;
		drawstrings(w);
	} else
	if (newact > w->topstring+w->height-3)
	{
		w->topstring = newact - w->height + 3;
		drawstrings(w);
	} else
		drawscrwinstring(w,newact);
}

/* 	return values:
	>=0: enter pressed, selected string number returned
	 -1: unknown non-extended keycode next in conin
	 -2: unknown extended keycode next in conin
*/

int selectscrwin(struct scrwindow *w, void (*live)(void))
{
	char c,d,*hkc;
	int	i;

	winactivate(w);
	scrnewactive(w,w->active);/* fix list */

	for(;;)
	{
		while (!kbhit())
			if (live!=NULL) live();

		switch(c=getch())
		{
			case 0:
				switch(d=getch())
				{
					case 0x48: /* up */
						if (w->active)
							scrnewactive(w,w->active-1);
						break;

					case 0x50: /* down */
						if (w->strings[w->active]!=NULL)
							scrnewactive(w,w->active+1);
						break;

/*					case 0x4b:
						break;

					case 0x4d:
						break;
*/
					case 0x47: /* home */
						scrnewactive(w,0);
						break;

					case 0x4f: /* end */
						scrnewactive(w,w->numstr);
						break;

					case 0x49: /* page up */
						scrnewactive(w,w->active - (w->height-3));
						break;

					case 0x51: /* page down */
						scrnewactive(w,w->active + (w->height-3));
						break;

					default:
						ungetch(d);
						return -2;
				}
				break;
			case 13:
				return w->active;
			default:
				if (w->hotkeys!=NULL)
					for (hkc = w->hotkeys,i=0;*hkc!='\0';hkc++,i++)
						if (*hkc == c) return(i);
				ungetch(c);
				return -1;
		}
	}
}

char *kbdinput(int maxlen,int alpha)
{
	static char tempstr[100];
	char c;

	*tempstr = '\0';

	for(;;)
	{
		c=getkey();
		switch(c)
		{
			case 0:
				getkey();
				continue;

			case 27:
				return(NULL);

			case 8:
				if (strlen(tempstr))
				{
					tempstr[strlen(tempstr)-1]='\0';
					putch(c);
					putch(' ');
					putch(c);
				}
				break;

			case 13:
				return(tempstr);

			default:
				if (strlen(tempstr)<maxlen)
				{
					int	vv;

					if (!alpha)
					{
						if (((c < '0') || (c > '9')) && (c != '-'))
							continue;
					}
					else if ((c < 32) || (c > 'z')) continue;

					vv = strlen(tempstr);
					tempstr[vv]=c;
					tempstr[vv+1]='\0';
					putch(c);
				}
		}
	}
}

int	numinput(char *querytext,int len,int minval,int maxval)
{
	int value=-9999;
	char *d;

	window(1,1,80,25);
	textbackground(LIGHTGRAY);

	for (;((value < minval) || (value > maxval));)
	{
		gotoxy(1,25);
		clreol();
		textcolor(RED);
		cputs(querytext);
		textcolor(BLACK);
		d = kbdinput(len,0);
		if (d == NULL) return -9999;
		value = atoi(d);
	}
	return value;
}

#pragma argsused

int strinput(char *querytext,int len,char *input)
{
	char *d;

	window(1,1,80,25);
	textbackground(LIGHTGRAY);
	textcolor(RED);
	gotoxy(1,25);
	clreol();
	cputs(querytext);
	textcolor(BLACK);
	d = kbdinput(len,1);
	if (d==NULL) return -9999;
	strcpy(input,d);
	return 0;
}

void outmsg(char *msg)
{
	window(1,1,80,25);
	textbackground(LIGHTGRAY);
	gotoxy(1,25);
	clreol();
	textcolor(RED);
	cputs(msg);
}

int	confirm(char *msg)
{
	window(1,1,80,25);
	textbackground(LIGHTGRAY);
	gotoxy(1,25);
	clreol();
	textcolor(RED);
	cputs(msg);
	return(tolower(getkey())=='y');
}

void scrwinputs(struct scrwindow *s,int x,int y,char *str)
{
	winactivate(s);
	gotoxy(x+1,y+1);
	cputs(str);
}
