#include <dos.h>
#include <asm.h>

void putpixel(int x,int y,int color)
{
   unsigned char far *p;

   if (x<0||x>319)return;
   if (y<0||y>319)return;
   p = (unsigned char far *)MK_FP(0xa000,(y*320)+x);
   *p = color;
}

void vertline(int x1,int y1,int y2,int color)
{
   int i;
   unsigned char far *p;

   p = (unsigned char far *)MK_FP(0xa000,(y1*320)+x1);
   for (i=y1;i<y2;i++,p += 320)
       *p = color;
}

void horizline(int x1,int y1,int x2,int color)
{
   int i;
   unsigned char far *p;

   p = (unsigned char far *)MK_FP(0xa000,(y1*320)+x1);
   for (i=x1;i<x2;i++)
       *p++ = color;
}

void bar(int x1,int y1,int x2,int y2,int color)
{
   int i,j;
   int delta;
   unsigned char far *p;

   delta = 320-(x2-x1);

   p = (unsigned char far *)MK_FP(0xa000,(y1*320)+x1);
   for (i=y1;i<y2;i++,p+=delta)
   {
       for (j=x1;j<x2;j++)
          *p++ = color;
   }
}


void grinit(void)
{
   int i;
   MOV   ax,13h
   INT   10h
}

void textinit(void)
{
   MOV   ax,3
   INT   10h
}

