#include <alloc.h>
#include <stdlib.h>
#include <string.h>

#include "midi.h"
#include "globdat.h"
#include "node2win.h"

int nodecount(struct ln_node *ln)
{
	int	i=0;

	while (ln != NULL)
	{
		ln = SUCC(ln);
		i++;
	}
	return i;
}

/* fjerner strenge samt pointer array fra hukommelsen */

void freestrings(char **s)
{
	if (s!=NULL)
	{
		while (*s != NULL)
			free(*(s++)); /* free string */
		free(s); /* free pointer list */
	}
}


/* laver listen for sequence list vinduet */

void buildseqlist(void)
{
	char **s;
	int	nums,i;
	struct sequence *sq;

	freestrings(seqwindowstr);

	nums = nodecount(SUCC(&seq.ln))+1; /* skip base node, add one for NULL */
	s=seqwindowstr = calloc(sizeof(void *),nums);
   if (s==0)memerr();

	sq = SUCC(&seq.ln);
	for (i=0;i<nums-1;i++)
	{
		*s = malloc(SEQNAMELEN+1);
      if (*s==0) memerr();

		strcpy(*s++, sq -> name);
		sq = SUCC(sq);
	}
	*s = NULL;
}

/* laver listen for track list vinduet */

void buildtracklist(void)
{
	char **s;
	int	numt,i;
	struct track *tr;

	freestrings(trackwindowstr);

	numt = nodecount(SUCC(&trk.ln))+1; /* skip base node, add one for NULL */
	s=trackwindowstr = calloc(sizeof(void *),numt);
   if (s==0)memerr();

	tr = SUCC(&trk.ln);
	for (i=0;i<numt-1;i++)
	{
		*s = malloc(TRACKNAMELEN+1);
      if (*s==0) memerr();

		strcpy(*s++, tr -> name);
		tr = SUCC(tr);
	}
	*s = NULL;
}

/* laver tracklisten for en sekvens */

char **buildseqtracks(struct sequence *s)
{
	int	numt,i;
	struct tnode *tn;
	char **str,**ss;

	numt = nodecount(SUCC(&s->tlist.ln))+1;
	str = ss = calloc(sizeof(void *),numt);
   if (ss==0)memerr();

	tn = SUCC(&s->tlist.ln);

	for (i=0;i<numt-1;i++)
	{
		*ss = malloc(TRACKNAMELEN+1);
      if (*ss==0) memerr();

		strcpy(*ss++, tn -> trk -> name);
		tn = SUCC(tn);
	}
	*ss = NULL;

	return str;
}

/* laver sequence-listen for en song */

char **buildsongseq(struct songnode *s)
{
	int	nums,i;
	struct songnode *sn;
	char **str,**ss;

	nums = nodecount(SUCC(&s->ln))+1;
	str = ss = calloc(sizeof(void *),nums);
   if (ss==0)memerr();

	sn = SUCC(&s->ln);

	for (i=0;i<nums-1;i++)
	{
		*ss = malloc(SEQNAMELEN+1);
      if (*ss==0) memerr();
		strcpy(*ss++, sn -> seq -> name);
		sn = SUCC(sn);
	}
	*ss = NULL;

	return str;
}
