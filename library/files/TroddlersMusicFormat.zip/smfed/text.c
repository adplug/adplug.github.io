#include <dos.h>
#include <asm.h>
#include "text.h"

static int _x,_y;
static int _textcolor;
static unsigned char far *_ddfont; // double dot 8x8 font

void gotoxy(int x,int y)
{
   _x = x-1;
   _y = y-1;
}

void textcolor(int c)
{
   _textcolor=c;
}

void outtext(const char *tx)
{
   unsigned offs;
   unsigned x,y;
   char c;
   unsigned color;
   unsigned char far *fontp;

   x = _x; y=_y;
   color=_textcolor;

   CLD

   while((c=*tx++)!=0)
   {
      offs = (x*8)+(y*320*8);
      fontp = _ddfont+(c*8);

      PUSH  ds
      PUSH  es
      PUSH  si
      PUSH  di

      MOV   si,word ptr fontp
      MOV   ds,word ptr fontp+2

      MOV   di,word ptr offs
      MOV   ax,0a000h
      MOV   es,ax
      MOV   cx,8

nxcx:
      LODSB
      MOV  bl,al
      MOV  ax,color
      MOV  dl,80h

nxdl:
      TEST  dl,bl
      JZ    nopix
      STOSB
      SHR   dl,1
      JNZ   nxdl
      JMP   enddl
nopix:
      MOV   es:[di],ah
      INC   di
      SHR   dl,1
      JNZ   nxdl
enddl:
      ADD   di,320-8
      LOOP  nxcx

      POP   di
      POP   si
      POP   es
      POP   ds
      x++;
   }
   _x = x;
}

void __textinit(void)
{
   PUSH  si
   PUSH  di
   PUSH  bp
   PUSH  es
   MOV   ax,1130h
   MOV   bh,3
   INT   10h
   MOV   ax,bp
   MOV   bx,es
   POP   es
   POP   bp
   POP   di
   POP   si
   MOV   word ptr _ddfont,ax
   MOV   word ptr _ddfont+2,bx
}

#pragma startup __textinit